/*
   SynScopeV

   Copyright (C) 2008,2009:
         Daniel Roggen, droggen@gmail.com

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

#include <QKeyEvent>
#include <QMessageBox>
#include <QPainter>
#include <QFileDialog>
#include <QFile>
#include <QTextStream>
#include <QXmlStreamWriter>
#include <QDir>
#include <QThread>
#include <QSplitter>
#include <QProgressDialog>
#include <Phonon/VideoWidget>

#include <string>
#include <vector>
#include <fstream>
#include <sstream>
#include <iostream>
#include <iterator>
#include <assert.h>

#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "referencesdialog.h"
#include "resampledialog.h"
#include "matlabcodedialog.h"
#include "sourcedialog.h"
#include "savesyncfiledialog.h"
#include "videowidgetext.h"
#include "helpdialog.h"
#include "cio.h"
//#include "helper.h"
#include "QVideoEncoder.h"
#include "exportvideodialog.h"
#include "exportmosaicvideodialog.h"
#include "precisetimer.h"


/*
   In order to link signal and videos, sources are internally referenced by an ID. This ID does not make distinction between signal or video source.
   All the reference points sources, and relation equations, use this ID.
   ID e [0;NumVideoSource[ -> ID corresponds to a video source
   ID e [NumVideoSource;NumVideoSource+NumSignalSource[ -> ID corresponds to a signal source


*/


// <3;title;1 2 3;xscale=2;yscale = 2 10;color = ff0000 00ff00 0000ff><2;tata;0 1 ;xscale=-12;yscale = auto;color = ff0000 00ff00 0000ff>

//<3;Source new;4 5 6 ;xscale=1;yscale =-3000 3000;color = ff0000 00ff00 0000ff>


//-------------------------------------------------------------------------------------------------
// SplitInVector
//-------------------------------------------------------------------------------------------------
// Returns false in case of failure.
// Only one split character is allowed
template<class T> bool SplitInVector(string str,string split,vector<T> &r,ios_base&(&b)(ios_base&)=dec)
{

   r.clear();
   QString qstr(str.c_str());
   QStringList sl = qstr.split(QString(split.c_str()),QString::SkipEmptyParts);
   for(int i=0;i<sl.size();i++)
   {
      std::istringstream iss(sl[i].toStdString());
      T j;
      if( !((iss >> b >> j).fail()))
         r.push_back(j);
      else
         return false;
   }
   return true;
}
template<class T> bool SplitInVector(QString &qstr,QString &split,vector<T> &r,ios_base&(&b)(ios_base&)=dec)
{
   r.clear();
   QStringList sl = qstr.split(split,QString::SkipEmptyParts);
   for(int i=0;i<sl.size();i++)
   {
      std::istringstream iss(sl[i].toStdString());
      T j;
      if( !((iss >> b >> j).fail()))
         r.push_back(j);
      else
         return false;
   }
   return true;
}

void MainWindow::SetUndoable(bool u)
{
   undoable = u;
   ui->actionUndo->setEnabled(undoable);
}

/**
  \brief MainWindow constructor: initialization and co.
**/
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent), ui(new Ui::MainWindow)
{

#ifdef DEVELMODE
   ConsoleInit();
#endif

   source_primary=source_secondary=-1;  // No primary/secondary view set.
   DeafToSliderEvents=false;
   DeafToVideoSliderEvents=0;



   ui->setupUi(this);

   // Complete the UI setup

   // Prepare the signal/video scroll areas, with a splitter.
   signalVideoSplitter = new QSplitter(this);
   scrollArea=new QScrollArea(this);
   scrollArea->setWidgetResizable(true);
   videoScrollArea=new QScrollArea(this);
   videoScrollArea->setWidgetResizable(true);
   signalVideoSplitter->addWidget(videoScrollArea);
   signalVideoSplitter->addWidget(scrollArea);
   signalVideoSplitter->setOrientation(Qt::Vertical);
   ui->centralWidget->layout()->addWidget(signalVideoSplitter);

   // Create the frame in the scroll area
   mainFrame = new QFrame(this);
   mainFrame->setFrameStyle(QFrame::NoFrame);
   mainFrame->setFrameShadow(QFrame::Raised);
   scrollArea->setWidget(mainFrame);

   // Create the layout in the scroll area frame
   signalVerticalLayout = new QVBoxLayout();
   mainFrame->setLayout(signalVerticalLayout);

   // Create the video scroll area
   mainVideoFrame = new QFrame();
   mainVideoFrame->setFrameStyle(QFrame::NoFrame);
   mainVideoFrame->setFrameShadow(QFrame::Raised);
   videoScrollArea->setWidget(mainVideoFrame);
   videoLayout = new QHBoxLayout();
   mainVideoFrame->setLayout(videoLayout);


   // Prepare the dialog box showing the reference points.
   RefDialog = new ReferencesDialog(this);
   connect(RefDialog,SIGNAL(AddReference()),this,SLOT(on_AddReference()));
   connect(RefDialog,SIGNAL(RemoveReference(int)),this,SLOT(on_RemoveReference(int)));
   connect(RefDialog,SIGNAL(ChangedActiveRelations()),this,SLOT(on_ChangedActiveRelations()));
   connect(RefDialog,SIGNAL(ReferenceSelected(int)),this,SLOT(on_ReferenceSelected(int)));





   /*std::vector<int> v;
   v.resize(4,0);
   RefPoints.resize(12,v);
   for(int i=0;i<RefPoints.size();i++)
   {
      RefPoints[i][0] = i%3;
      RefPoints[i][1] = rand();
      RefPoints[i][2] = (i*3)%5;
      RefPoints[i][3] = rand();

   }

   RefDialog->SetReferencePoints(RefPoints);
   */




   //timer=startTimer(1000);

   //ui->lineEdit_View->setPlainText("<0;Source 0;1 2 3;xscale=1;yscale = -300 300;color = ff0000 00ff00 0000ff><1;Source 1;0 1 ;xscale=1;yscale = -500 500;color = ff0000 00ff00><2;Source 2;0 2;xscale=1;yscale = -300 300;color = FFFFFF FF0000><0;Source 0 bis;0 2 4;xscale=1;yscale = -300 300>");
   //ui->lineEdit_View->setPlainText("<0;Source 0;0 1;xscale=1;yscale = -300 300;color = ff0000 00ff00><1;Source 1;0 1;xscale=1;yscale = -500 500;color = ff0000 00ff00><2;Source 2;0 1;xscale=1;yscale = -300 300;color = FFFFFF FF0000><0;Source 0 bis;2;xscale=1;yscale = -300 300><3;Source 3(file3.dat);0;xscale=1;yscale = -300 300><4;Source 4(file4.dat);0;xscale=1;yscale = -300 300>");
   //ui->lineEdit_Source->setPlainText("<signal;../file1.dat><video;file.avi><signal;../file2.dat><signal;../file3.dat>");
   //ui->lineEdit_Source->setPlainText("<signal;../file0.dat><video;file.avi><signal;../file1.dat><signal;../file2.dat><signal;../file3.dat><signal;../file4.dat>");
   //ui->lineEdit_Source->setPlainText("<signal;../file0.dat><video;../vid1.avi><video;../vid2.avi><video;../vid3.avi><signal;../file1.dat><signal;../file2.dat><signal;../file3.dat><signal;../file4.dat>");

   SB_LabelSignal=new QLabel(statusBar());
   statusBar()->addWidget(SB_LabelSignal);
   SB_LabelPosition=new QLabel(statusBar());
   statusBar()->addWidget(SB_LabelPosition);
   SB_LabelCenter=new QLabel(statusBar());
   statusBar()->addWidget(SB_LabelCenter);
   SB_LabelSource=new QLabel(statusBar());
   statusBar()->addWidget(SB_LabelSource);

   SetUndoable(false);






}

/**
	\brief Destructor
**/
MainWindow::~MainWindow()
{
    delete ui;
}
/**
**/
void MainWindow::AddSignalView(VIEWDATA &vd)
{
   vd.frame = new QFrame();
   vd.frame->setFrameStyle(QFrame::Panel);
   vd.frame->setFrameShadow(QFrame::Raised);
   vd.frame->setAutoFillBackground(true);
   //vd.scope = new DScopeQTWidget(0,0,200,100,0);
   vd.scope = new DScopeQTExtWidget(0,0,200,100,0);
   vd.scope->setMinimumHeight(50);
   vd.slider = new QSlider(Qt::Horizontal,0);
   vd.box = new QVBoxLayout();
   vd.box->addWidget(vd.scope);
   vd.box->addWidget(vd.slider);
   vd.frame->setLayout(vd.box);

   signalVerticalLayout->addWidget(vd.frame);
   ViewData.push_back(vd); // Keep for further use.
   // Add a handler
   int success;
   success=connect(vd.slider,SIGNAL(valueChanged(int)),this,SLOT(on_Slider_valueChanged(int)));
   success=connect(vd.scope,SIGNAL(mousePressed(Qt::MouseButton,int)),this,SLOT(on_Source_mousePressed(Qt::MouseButton,int)));
   success=connect(vd.scope,SIGNAL(mouseMoved(int)),this,SLOT(on_Source_mouseMoved(int)));
   success=connect(vd.scope,SIGNAL(Repaint()),this,SLOT(on_Repaint()));



   ViewData[ViewData.size()-1].scope->SetTitle(ViewData[ViewData.size()-1].title);
   ViewData[ViewData.size()-1].scope->SetAlignment(true);
   ViewData[ViewData.size()-1].scope->SetGridPosition(true);


   if(ViewData[ViewData.size()-1].yauto)
      ViewData[ViewData.size()-1].scope->SetVAuto();
   else
      ViewData[ViewData.size()-1].scope->SetVRange(ViewData[ViewData.size()-1].yscale[0],ViewData[ViewData.size()-1].yscale[1]);
   ViewData[ViewData.size()-1].scope->HZoom(ViewData[ViewData.size()-1].xscale);
   ViewData[ViewData.size()-1].slider->setRange(0,SignalData[ViewData[ViewData.size()-1].source].data[0].size());
}

/**
   \brief Set min/max range of signal sliders according to source length
**/

void MainWindow::AdjustSignalViewSlider()
{
   for(unsigned int i=0;i<ViewData.size();i++)
   {
      ViewData[i].slider->setRange(0,SignalData[ViewData[i].source].data[0].size());
   }
}

/**
  \brief Delete all the signal views, free the widgets
**/
void MainWindow::DeleteSignalViews()
{
   int numviews=ViewData.size();
   for(int i=0;i<numviews;i++)
   {
      signalVerticalLayout->removeWidget((ViewData.end()-1)->frame);
      delete (ViewData.end()-1)->slider;
      delete (ViewData.end()-1)->scope;
      delete (ViewData.end()-1)->box;
      delete (ViewData.end()-1)->frame;
      ViewData.erase(ViewData.end()-1);
   }
}





/**
  \brief Plots the content of a view

**/
void MainWindow::PlotView(int view)
{
   if(SignalData.size()==0)
      return;
   //printf("PlotView %d\n",view);
   // Make sure we have the data



   // Iterate all traces of the scope
   vector<vector<int> *> vd;		// data for the traces in this scope
   vector<unsigned> vc;			// colors  of the traces
   PreparePlotView(view,vd,vc);
   ViewData[view].scope->Plot(vd,vc);
   ViewData[view].scope->repaint();
}

/**
  \brief Prepares the data to plot the content of a view
**/
void MainWindow::PreparePlotView(int view,vector<vector<int> *> &vd,vector<unsigned> &vc)
{

   assert(ViewData[view].source<SignalData.size());

   vd.clear();
   vc.clear();

   for(unsigned t=0;t<ViewData[view].traces.size();t++)
   {
      // If trace available
      if(ViewData[view].traces[t]<SignalData[ViewData[view].source].data.size())
      {
         //printf("%d ",ViewData[view].traces[t]);
         vd.push_back(&SignalData[ViewData[view].source].data[ViewData[view].traces[t]]);
         if(ViewData[view].colors.size()!=0)
            vc.push_back(ViewData[view].colors[t]);
         else
            vc.push_back(0xffffffff);
      }
   }
}



/**
  \brief Set the scroll bar positions of the signal views to the 'centersample' value of the sources

  Redraws all the signal/video views, or only selected ones specified by vid and sid.
**/
void MainWindow::SetAllSliderPosition(bool all,vector<int> vid,vector<int> sid)
{
   DeafToSliderEvents=true;

   if(all)
      DeafToVideoSliderEvents=VideoViewData.size();
   else
      DeafToVideoSliderEvents=vid.size();

   // Iterate all the videos
   for(unsigned i=0;i<VideoViewData.size();i++)
   {
      if(all || std::find(vid.begin(),vid.end(),i)!=vid.end())
      {
         // Only seek the video if we update all, or if the video id is in vid.
         VideoViewData[i].mo->seek(VideoViewData[i].centersample);
      }
   }
   // Iterate all the signals
   for(unsigned i=0;i<ViewData.size();i++)
   {
      if(all || std::find(sid.begin(),sid.end(),ViewData[i].source)!=sid.end())
      {
         // Only seek the signal if we update all, or if the signal id is in sid.
         ViewData[i].slider->setSliderPosition(SignalData[ViewData[i].source].centersample);
         ViewData[i].scope->SetSampleOffset(SignalData[ViewData[i].source].centersample);
         PlotView(i);
      }
   }

   DeafToSliderEvents=false;
}

/**
  \brief Handles repaint and synchronization of views upon slider activity
**/
void MainWindow::on_Source_Slided(int sourceidx,int value)
{
   assert(sourceidx!=-1);

   std::map<int,int> offsetout;
   ComputeAllSourceOffsetFrom(RelationsActive,sourceidx,value,offsetout);

   // Status bar update
   SetSBLabelPointer(sourceidx);

   vector<int> vid,sid;    // Memorize which sliders are affected by the linking

   // Set the center sample value - but do not effect it yet.
   for(std::map<int,int>::iterator it = offsetout.begin();it!=offsetout.end();it++)
   {
      SetCenterSample(it->first,it->second);
      if(IsIdxVideo(it->first))
         vid.push_back(IDX2VID(it->first));
      else
         sid.push_back(IDX2SID(it->first));
   }

   // Effect center sample only on affected signals
   SetAllSliderPosition(false,vid,sid);
}
void MainWindow::on_Slider_valueChanged(int value)
{
   QObject *s = sender();

   if(DeafToSliderEvents)
      return;

   for(unsigned i=0;i<ViewData.size();i++)
   {
      if(ViewData[i].slider == s)
      {
         on_Source_Slided(SID2IDX(ViewData[i].source),value);
         break;
      }
   }


}




void MainWindow::PlotAllSignalViews()
{
   for(unsigned i=0;i<ViewData.size();i++)
      PlotView(i);
}

/*void MainWindow::timerEvent(QTimerEvent *event)
{
   PlotAllSignalViews();
}*/












/**
  \brief Export Matlab resample code
**/
void MainWindow::on_actionExport_Matlab_resample_code_triggered()
{
    Resample(false);
}
/**
  \brief In-place resample
**/
void MainWindow::on_action_Resample_triggered()
{
   Resample(true);
}
/**
  \brief Handles the high-level GUI resample; asking user options, creating the resample logic, and applying it.
**/
void MainWindow::Resample(bool inplace)
{
   bool prepend,postpend;


   // Find disconnected graphs
   vector<RELATIONS> graphs = FindGraphs(RelationsActive);
   // Find the resample logic - only to check if there are signal relations available.
   map<int,RESAMPLEREL> m = ResampleLogic(graphs,prepend);
   //printf("m size: %d\n",m.size());

   if(m.size()==0)
   {
      QMessageBox::information(this,"Resample","No signals to resample: first, link the signals that must be jointly resampled.");
      return;
   }


   ResampleDialog *rdlg = new ResampleDialog(this);
   if(inplace)
      rdlg->SetC();
   else
      rdlg->SetMatlab();
   if(rdlg->exec() == QDialog::Rejected)
      return;
   int strategy = rdlg->getStrategy();
   int method = rdlg->getMethod();
   delete rdlg;

   switch(strategy)
   {
      case 2:
         prepend=true;
         postpend=true;
         break;
      case 1:
         prepend=true;
         postpend=false;
         break;
      default:
         prepend=false;
         postpend=false;
   }

   // Re-run the resample logic, this time with the user defined parameters.
   m = ResampleLogic(graphs,prepend);

   // Apply the logic
   if(inplace)
   {
      // keep undo data
      SignalDataUndo=SignalData;
      RefPointsUndo=RefPoints;
      SetUndoable(true);
      ResampleInPlace(m,prepend,postpend);
      AdjustSignalViewSlider();
   }
   else
      ResampleMatlab(m,method==0 ? true : false,prepend,postpend);
}

/**
  \brief Prepares to merge the files. Ensures the sources to merge are all of identical length.
   If they are of identical length assume they were resampled.

**/
void MainWindow::MergeFiles()
{
   // Find disconnected graphs
   vector<RELATIONS> graphs = FindGraphs(RelationsActive);

   // Find the edges.
   GRAPHSRC GraphSrc,GraphSrcOk,GraphSrcNOk;
   GRAPHSRC GraphToSave;

   // Iterate each disconnected graph, and extracts&sort within that graph the connected edges.
   // Discard video edges, and converts IDX to Signal IDS
   for(unsigned i=0;i<graphs.size();i++)
   {
      vector<int> edges;

      if(IsIdxSignal(graphs[i][0].x1))
         edges.push_back(IDX2SID(graphs[i][0].x1));
      for(unsigned j=0;j<graphs[i].size();j++)
         if(IsIdxSignal(graphs[i][j].x2))
            edges.push_back(IDX2SID(graphs[i][j].x2));
      // Sort the edges
      sort(edges.begin(),edges.end());

      GraphSrc.push_back(edges);
   }

   // Check the graphs, to make sure within a graph all sources have the same length
   for(unsigned i=0;i<GraphSrc.size();i++)
   {
      int ml;
      bool ok=true;
      ml = SignalData[GraphSrc[i][0]].data[0].size();
      for(unsigned  j=0;j<GraphSrc[i].size();j++)
      {
         if(SignalData[GraphSrc[i][j]].data[0].size() != ml)
         {
            ok=false;
            break;
         }
      }
      if(ok)
         GraphSrcOk.push_back(GraphSrc[i]);
      else
         GraphSrcNOk.push_back(GraphSrc[i]);
   }

   //

   // Reports an information box if some selected sources are of different sizes, thus preventing a merge.
   if(GraphSrcNOk.size()!=0)
   {
      QString str="A number of linked signal sources have different lengths. This prevents these sources from being merged.\n\n";
      str+="Resample the linked sources before merging them.\n\n";
      str+="The following linked sources are concerned:\n";
      for(unsigned  i=0;i<GraphSrcNOk.size();i++)
      {
         str += GraphToString(GraphSrcNOk[i]);
         str+="\n";
      }
      str+="\nThese sources are discarded from the merge operation.\n";
      QMessageBox::information(this,"Merge sources",str);
   }
   if(GraphSrcOk.size()==0)
   {
      QMessageBox::information(this,"Merge sources","No signal sources to merge.");
      return;
   }

   SaveSyncFileDialog *dlg = new SaveSyncFileDialog(this);
   //dlg->SetGraphs(graphs);
   dlg->SetGraphs(GraphSrcOk);
   int rv = dlg->exec();
   GraphToSave = dlg->GetSaveOrder();
   delete dlg;

   if(rv)
   {
      // User asked to save one or more graphs.
      // Print them out.

      for(unsigned i=0;i<GraphToSave.size();i++)        // Iterate all the graphs
      {
         //printf("Saving graph %d\n",i);
         //printf("\t %s\n",GraphToString(GraphToSave[i]).toStdString().c_str());

         // Create some big signal stuff
         int nc=0;      // Number of channels in the merged data.
         int length;    // Lenght of the data to merge
         for(unsigned  j=0;j<GraphToSave[i].size();j++)
            nc += SignalData[GraphToSave[i][j]].data.size();
         length = SignalData[GraphToSave[i][0]].data[0].size();

         //printf("Resulting merged data will be %d channels and %d samples\n",nc,length);
         vector<vector<int> > newsignal(nc,vector<int>(length,0));

         // Fill the merged signal
         int cc=0;                                                            // Current channel
         for(unsigned  src=0;src<GraphToSave[i].size();src++)                       // Iterate all the sources within graph i
         {
            for(unsigned  c=0;c<SignalData[GraphToSave[i][src]].data.size();c++)    // Iterate all the channels in source src of graph i
            {
               for(unsigned  s=0;s<length;s++)                                      // Iterate all the samples
                  newsignal[cc][s] = SignalData[GraphToSave[i][src]].data[c][s];
               cc++;
            }
         }
         QString str=QString("Save merged sources ");
         str += GraphToString(GraphToSave[i]);

         SaveSignal(newsignal,str);
      }
   }
}



/**
  \brief Creates the signal views from the view definition string.
**/
void MainWindow::on_pushButton_ApplyView_clicked()
{
   SetupViews(ui->lineEdit_View->toPlainText().toStdString());
}
void MainWindow::SetupViews(string layout)
{
   // Preemptively delete all the views
   DeleteSignalViews();

   CurrentLayoutString = layout;

   VIEWDATAS vdv;
   int rv = ParseLayoutString(layout,vdv);
   if(rv!=0)
   {
      QString str;
      str.sprintf("Error number %d",rv);
      QMessageBox::information(this,"Syntax error in layout string",str);
      return;
   }



   // Check that all the views refer to available signal sources and channels.

   QString err="The following views refer to nonexistant sources or channels:\n\n";

   VIEWDATAS vdvvalid;
   bool iserr=false;
   for(unsigned i=0;i<vdv.size();i++)
   {
      if(vdv[i].source<SignalData.size())
      {
         // The view refers to a valid source. Check if all the traces refer to valid channels
         bool invalid=false;
         for(unsigned t=0;t<vdv[i].traces.size();t++)
         {
            if(vdv[i].traces[t]>=SignalData[vdv[i].source].data.size())
               invalid=true;
         }
         if(!invalid)
         {
            // The view is valid. Store it as valid
            vdvvalid.push_back(vdv[i]);
         }
         else
         {
            // Report the error
            iserr=true;
            err+=QString(" View %1: nonexistant traces in source %2\n").arg(i).arg(vdv[i].source);
         }
      }
      else
      {
         // The view refers to an unavailable source
         iserr=true;
         err+=QString(" View %1: nonexistant source %2\n").arg(i).arg(vdv[i].source);
      }
   }
   if(iserr)
   {
      err+=QString("\nInvalid views are discarded.\n");
      QMessageBox::information(this,"Error in view definitions",err);
   }

   for(unsigned i=0;i<vdvvalid.size();i++)
      AddSignalView(vdvvalid[i]);
}
/**-------------------------------------------------------------------------------------------------
// ParseLayoutString
// Layout string: <Source>;<title>;<traces>[;xscale=<xs>][;yscale=<auto|min;max>][;color=<colors>]>
//-------------------------------------------------------------------------------------------------
// Example: <Scope 2;4;yscale=-100 100>
**/
int MainWindow::ParseLayoutString(string str,VIEWDATAS &vdv)
{
   //scopesdefs.scopedefinition.clear();

   // Regexp for layout string:
   // Characters ;<> are excluded in the match of the expression for syntax checking.
   // Group 0: whole expression
   // Group 1: source
   // Group 2: title
   // Group 3: traces
   // Group 5: xscale
   // Group 7: yscale
   // Group 9: color
   // Validation of the whole string: look for multiple expressions with a '(expression)*' regex string.
   // Original string:
   //string expression = string("\\s*<\\s*([^;^>^<]*?)\\s*;\\s*([^;^>^<]+?)\\s*(;\\s*xscale\\s*=\\s*([^;^>^<]*?))?(;\\s*yscale\\s*=\\s*([^;^>^<]*?))?(;\\s*color\\s*=\\s*([^;^>^<]*?))?>\\s*");

   // Beware QRegExp does not support non greedy match *? and +? (anyway isn't needed)
   string expression = string("\\s*<\\s*([^;^>^<]*)\\s*;\\s*([^;^>^<]*)\\s*;\\s*([^;^>^<]+)\\s*(;\\s*xscale\\s*=\\s*([^;^>^<]*))?(;\\s*yscale\\s*=\\s*([^;^>^<]*))?(;\\s*color\\s*=\\s*([^;^>^<]*))?>\\s*");
   QRegExp e(QString(expression.c_str()));
   //printf("e.isValid: %d\n",(int)e.isValid());
   //printf("e.isValid: %s\n",e.errorString().toStdString().c_str());
   string expression2=string("(")+expression+string(")*");
   QRegExp validation(QString(expression2.c_str()));
   //printf("validation.isValid: %d\n",(int)validation.isValid());
   //printf("validation.isValid: %s\n",e.errorString().toStdString().c_str());


   // Validation
   int iin=validation.exactMatch(QString(str.c_str()));
   if(iin==-1)
   {
      //printf("Validation match failed\n");
      return -5;
   }


   // Expression parsing
   e.indexIn(QString(str.c_str()));
   unsigned midx=0;
   int pos = 0;
   while((pos = e.indexIn(QString(str.c_str()), pos)) != -1)
   {
      pos += e.matchedLength();

      /*printf("Capture group %d\n",midx);
      printf("NumCaptures: %d\n",e.numCaptures());
      for(int i=0;i<e.numCaptures()+1;i++)
         printf("Capture %d: %s\n",i,e.cap(i).toStdString().c_str());*/


      VIEWDATA vd;
      if(e.numCaptures()!=9)
      {
         //cout << "Invalid match size\n";
         return -9;
      }


      string source = e.cap(1).toStdString();
      vd.title = e.cap(2).toStdString();
      string traces = e.cap(3).toStdString();
      string xscale = e.cap(5).toStdString();
      string yscale = e.cap(7).toStdString();
      string color = e.cap(9).toStdString();

      vector<unsigned> d;
      vector<int> dxscale,dyscale;
      vector<string> dstring;
      bool ok;


      if(!SplitInVector(source,string(" "),d))
         return -19;
      if(d.size()!=1)
         return -19;
      vd.source=d[0];

      if(!SplitInVector(traces,string(" "),vd.traces))
         return -20;
      /*cout << "Traces: ";
      for(unsigned j=0;j<vd.traces.size();j++)
         cout << vd.traces[j] << "; ";
      cout << "\n";*/

      // Parse the X scale.
      if(!SplitInVector(xscale,string(" "),dxscale))
         return -21;
      if(dxscale.size()>1)
         return -22;
      if(dxscale.size()==0)
         vd.xscale=1;
      else
         vd.xscale=dxscale[0];
      //cout << "xscale: " << vd.xscale << "\n";


      // Parse the Y scale.
      if(!SplitInVector(yscale,string(" "),dstring))
         return -23;
      if(dstring.size()>2)
         return -24;
      switch(dstring.size())
      {
         case 0:
            vd.yauto=true;
            break;
         case 1:
            if(dstring[0].compare("auto")==0)
               vd.yauto=true;
            else
               return -25;
            break;
         case 2:
            vd.yauto=false;
            if(!SplitInVector(yscale,string(" "),vd.yscale))
               return -26;
            if(vd.yscale.size()!=2)
               return -27;
            if(vd.yscale[0]>vd.yscale[1])
            {
               int t=vd.yscale[0];
               vd.yscale[0]=vd.yscale[1];
               vd.yscale[1]=t;
            }
            if(vd.yscale[0]==vd.yscale[1])
               vd.yscale[0]--;
            break;
      }
      /*cout << "yscale: ";
      if(vd.yauto==true)
         cout << "auto\n";
      else
         cout << "[" << vd.yscale[0] << ";" << vd.yscale[1] << "]\n";*/

      // Parse the colors
      if(!SplitInVector(color,string(" "),vd.colors,hex))
         return -28;
      /*cout << "color: ";
      for(unsigned j=0;j<vd.colors.size();j++)
         cout << vd.colors[j] << "; ";
      cout << "\n";*/

      if(vd.colors.size()!=0 && (vd.colors.size() != vd.traces.size()))
         return -29;

      //cout << "\n";
      vdv.push_back(vd);

      midx++;
   }



   return 0;
}




/**
  \brief Ordinary Least Square Regression

  Finds a and b so that: x2 = b*x1 + a

  Returns false if regression is not possible, true otherwise.
**/
bool MainWindow::OLSQRegress(std::vector<double> x1,std::vector<double> x2, double &a, double &b)
{
   // Mean
   double x1m,x2m;
   x1m=x2m=0;
   for(int i=0;i<x1.size();i++)
   {
      x1m+=x1[i];
      x2m+=x2[i];
   }
   x1m/=(double)x1.size();
   x2m/=(double)x2.size();


   // b^
   b=0;
   double bn,bd;
   bn = 0;
   for(unsigned i=0;i<x1.size();i++)
      bn+=(x1[i]-x1m)*(x2[i]-x2m);
   bd = 0;
   for(unsigned i=0;i<x1.size();i++)
      bd+=pow(x1[i]-x1m,2.0);
   if(bd==0)
      return false;
   b = bn/bd;

   // a^
   a = x2m-b*x1m;
   return true;
}
// x2 is y
bool MainWindow::OrthogonalLSQRegression(std::vector<double> x1,std::vector<double> x2, double &a, double &b)
{
   // Mean
   double x1m,x2m;

   int n = x1.size();
   if(n==0)
      return false;

   x1m=x2m=0;
   for(int i=0;i<n;i++)
   {
      x1m+=x1[i];
      x2m+=x2[i];
   }
   x1m/=(double)n;
   x2m/=(double)n;


   double Bn=0;
   for(int i=0;i<n;i++)
   {
      Bn+=pow(x2[i],2.0);
      Bn-=pow(x1[i],2.0);
   }
   Bn -= ((double)n) * pow(x2m,2.0);
   Bn += ((double)n) * pow(x1m,2.0);

   double Bd=0;
   double sx1=0,sx2=0,sx1x2=0;
   for(int i=0;i<n;i++)
   {
      sx1 += x1[i];
      sx2 += x2[i];
      sx1x2 += x1[i]*x2[i];
   }
   Bd = (1.0/(double)n) * sx1 * sx2 - sx1x2;


   if(Bd==0)
      return false;

   double B = 0.5 * Bn / Bd;



   double b1,b2;
   double a1,a2;


   if(1.0+B*B<0)
      return false;

//   printf("x1m %lf x2m %lf sx1 %lf sx2 %lf sx1x2 %lf\n",x1m,x2m,sx1,sx2,sx1x2);
//   printf("Bn %lf Bd %lf B %lf\n",Bn,Bd,B);

   b1 = -B + sqrt(1.0+B*B);
   b2 = -B - sqrt(1.0+B*B);

   a1 = x2m - b1 * x1m;
   a2 = x2m - b2 * x1m;



   //printf("Option 1: x2 = x1 * %lf + %lf\n",b1,a1);
   //printf("Option 2: x2 = x1 * %lf + %lf\n",b2,a2);

   // Need to decide between the two linear fit.

   // We return the positive slope. This assumes there is no negative correlation in the input data.
   if(b1<0)
   {
      a=a2;
      b=b2;
   }
   else
   {
      a=a1;
      b=b1;
   }




   return true;
}



/**
  \brief Compute the signal relations from the reference points
**/
void MainWindow::ComputeRelations()
{
   // Do a regression test.
   double a,b;
   std::vector<double> x1,x2;

   RELATIONS RelationsNew;
   RELATIONS RelError;
   RELATIONS RevRelError;
   QString strign="These relation(s) are ignored. Check reference points consistency.\n";
   QString strlinkerror="Link equation(s) error";

   RelationsAvailable.clear();

   // Exhaustive search
   for(int s1=0;s1<GetNumSources();s1++)
   {
      for(int s2=0;s2<GetNumSources();s2++)
      {
         //printf("******************** LSQ %d %d\n",s1,s2);
         x1.clear();
         x2.clear();
         // Collect all the source points in x1,x2
         for(unsigned i=0;i<RefPoints.size();i++)
         {
            if(RefPoints[i][0]==s1 && RefPoints[i][2]==s2)
            {
               x1.push_back(RefPoints[i][1]);
               x2.push_back(RefPoints[i][3]);
            }
            if(RefPoints[i][0]==s2 && RefPoints[i][2]==s1)
            {
               x1.push_back(RefPoints[i][3]);
               x2.push_back(RefPoints[i][1]);
            }
         }
         // Regression via ordinary least squares
         //if(OLSQRegress(x1,x2,a,b))
         if(OrthogonalLSQRegression(x1,x2,a,b))
         {
            //printf("x%d=x%d %.3lf + %.3lf\n",s2,s1,b,a);
            // Store the relation
            RELATION r;
            r.x1 = s1;
            r.x2 = s2;
            r.b = b;
            r.a = a;
            r.s1 = IsIdxSignal(r.x1);
            r.s2 = IsIdxSignal(r.x2);
            if(r.s1)
               r.tx1=IDX2SID(r.x1);
            else
               r.tx1=IDX2VID(r.x1);
            if(r.s2)
               r.tx2=IDX2SID(r.x2);
            else
               r.tx2=IDX2VID(r.x2);

            // Ensure no negative relations
            if(r.b<0)
               RelError.push_back(r);
            else
               RelationsNew.push_back(r);       // Keep erroneous relations - report at the end in a single shot.

            //printf("Ordinary LSQ: x2 = x1 * %lf + %lf\n",r.b,r.a);
            //printf("Orthogonal LSQ: x%d = x%d * %lf + %lf\n",s2,s1,r.b,r.a);
         }
         /*else
         {
            printf("Orthogonal LSQ failed\n");
         }*/
         // Try the ortogonal
         //printf("Orthogonal LSQ\n");
         //bool suc=OrthogonalLSQRegression(x1,x2,a,b);
         //if(suc==false) printf("orthogonal LSQ failed\n");
         

      }
   }
   // Check irreversible relations
   bool revrelok;
   for(RELATIONS::iterator r1=RelationsNew.begin();r1!=RelationsNew.end();r1++)
   {
      // For relation r1.x1->r1.x2, a reversible relation r2.x2->r2.x1 must exist
      revrelok=false;
      for(RELATIONS::iterator r2=RelationsNew.begin();r2!=RelationsNew.end();r2++)
      {
         if(r1->x1 == r2->x2 && r1->x2 == r2->x1)
         {
            revrelok=true;
            break;
         }
      }
      if(revrelok==false)
      {
         // No reversible relation found, report it.
         RevRelError.push_back(*r1);
      }
   }
   // Remove the non-reversible relations.
   if(RevRelError.size()!=0)
   {
      // Iterator on erroneous relations
      RELATIONS::iterator re = RevRelError.begin();

      // Iterate new relations
      for(RELATIONS::iterator r1=RelationsNew.begin();r1!=RelationsNew.end();r1++)
      {
         if( re!=RevRelError.end() && r1->x1 == re->x1 && r1->x2 == re->x2 )
         {
            // r1 is an erroneous relation; we don't add it to available relations, and we look for the next erroneous relation
            re++;    // This is correct as erroneous relations are stored in parallel to RelationsNew.
         }
         else
         {
            // r1 is a valid relation.
            RelationsAvailable.push_back(*r1);
         }
      }
   }
   else
      RelationsAvailable = RelationsNew;

   // Report errors
   QString strerr;
   if(RelError.size())
   {
      strerr+="The following signal links are invalid (negative correlation):\n";
      for(RELATIONS::iterator r=RelError.begin();r!=RelError.end();r++)
      {
         QString str2;
         str2.sprintf("x%d = x%d * %lf + %lf.\n",r->x2,r->x1,r->b,r->a);
         strerr+=str2;
      }
   }
   if(RevRelError.size())
   {
      strerr+="The following signal links are not reversible:\n";
      for(RELATIONS::iterator r=RevRelError.begin();r!=RevRelError.end();r++)
      {
         QString str2;
         str2.sprintf("x%d - x%d\n",r->x1,r->x2);
         strerr+=str2;
      }
   }

   if(RelError.size()!= 0 || RevRelError.size()!=0)
      QMessageBox::information(this,strlinkerror,strerr+strign);

   /*printf("Checking if relations are okay\n");
   RELATIONS::iterator it;
   for(it=RelationsAvailable.begin();it!=RelationsAvailable.end();it++)
   {
      printf("x%d = x%d * %.1lf + %1lf\n",it->x2,it->x1,it->b,it->a);
   }*/

   // Update the user interface
   RefDialog->InitRelationsUI(SignalData.size(),VideoViewData.size());
   RefDialog->SetRelationsAvailable(RelationsAvailable);
   UpdateRelationsActive();
}

void MainWindow::ClearActiveRelations()
{
   RefDialog->SetRelationsAvailable(RelationsAvailable);
}

/**
   \brief Remove all the video views
**/
void MainWindow::DeleteVideoViews()
{
   for(int i=0;i<VideoViewData.size();i++)
   {
      VideoViewData[i].mo->stop();

      // Delete layout first
      //printf("Delete hboxctrl\n");
      delete VideoViewData[i].hboxctrl;
      //printf("Delete hboxvid\n");
      delete VideoViewData[i].hboxvid;
      //printf("Delete vbox\n");
      delete VideoViewData[i].vbox;


      //printf("Delete slider\n");
      //delete VideoViewData[i].slider;
      //printf("Delete volumeSlider\n");
      //delete VideoViewData[i].volumeSlider;
      //printf("Delete audiooutput\n");
      //delete VideoViewData[i].audioOutput;
      //printf("Delete videowidget\n");
      //delete VideoViewData[i].vw;
      //printf("Delete mediaobject\n");
      //delete VideoViewData[i].mo;
      //printf("Delete button\n");
      delete VideoViewData[i].button;
      //printf("Delete frame\n");
      delete VideoViewData[i].frame;
      // The MediaSource is deleted automatically by the MediaObject.
      //printf("loop %d\n",i);
   }
   VideoViewData.clear();
}


/**
  \brief Adds a video.

  If the video file is not found, this function reports it but nevertheless creates the GUI elements.

  \warning: Phonon's ability to render the video isn't tested. File existence is tested outside of Phonon
**/
void MainWindow::addVideo(QString file)
{
   // Opens in one existing widged
   VIDEOVIEWDATA vd;

   // Test file existence
   QDir dir;
   if(!dir.exists(file))
   {
      QMessageBox::critical(this,"Load video file",QString("File '%1' does not exist").arg(file));
   }

   // Keep filename
   vd.file = file;
   vd.centersample=0;

   // Create the widgets and layouts
   vd.hboxctrl = new QHBoxLayout();
   vd.hboxvid = new QHBoxLayout();
   vd.vbox = new QVBoxLayout();
   QIcon icon(":playpause.png");
   vd.button = new QPushButton(icon,"");
   vd.frame = new QFrame();
   vd.frame->setFrameStyle(QFrame::Panel);
   vd.frame->setFrameShadow(QFrame::Raised);
   vd.frame->setAutoFillBackground(true);




   // Create the video related widgets
   vd.mo = new Phonon::MediaObject(this);
   vd.src = new Phonon::MediaSource(file);
   vd.mo->setCurrentSource(*vd.src);
   vd.mo->setTickInterval(500);
   vd.vw = new VideoWidgetExt(this);
   Phonon::createPath(vd.mo, vd.vw);
   vd.audioOutput = new Phonon::AudioOutput(Phonon::VideoCategory, this);
   Phonon::createPath(vd.mo, vd.audioOutput);

   // Seek slider
   vd.slider = new Phonon::SeekSlider(this);
   vd.slider->setMediaObject(vd.mo);
   vd.slider->setSingleStep(20);

   // Volume slider
   vd.volumeSlider = new Phonon::VolumeSlider;
   vd.volumeSlider->setOrientation(Qt::Vertical);
   vd.volumeSlider->setMuteVisible(false);
   vd.volumeSlider->setAudioOutput(vd.audioOutput);

   vd.vw->setVisible(true);
   vd.vw->setScaleMode(Phonon::VideoWidget::FitInView);
   //vd.vw->setScaleMode(Phonon::VideoWidget::ScaleAndCrop);

   // Start the video
   vd.mo->pause();

   // Set up the horizontal layout: slider and play/pause button
   vd.hboxctrl->addWidget(vd.slider);
   vd.hboxctrl->addWidget(vd.button);
   vd.hboxctrl->addWidget(vd.volumeSlider);

   // Center the video video
   vd.hboxvid->addWidget(vd.vw);

   // Set-up the vertical layout: video widget, and slider/button
   vd.vbox->addLayout(vd.hboxvid);
   vd.vbox->addLayout(vd.hboxctrl);

   // Setup the layout in the frame
   vd.frame->setLayout(vd.vbox);

   // Add the frame to the video scroll area
   videoLayout->addWidget(vd.frame);

   // Keep data
   VideoViewData.push_back(vd);

   // Add a button handler
   connect(vd.button, SIGNAL(clicked(bool)), this, SLOT(VideoPlayPauseButton(bool)));

   // Add various video handlers
   connect(vd.button, SIGNAL(clicked(bool)), this, SLOT(on_videoPlayPauseButton(bool)));
   connect(vd.mo,SIGNAL(tick(qint64)),this,SLOT(on_Video_tick(qint64)));
   connect(vd.mo,SIGNAL(stateChanged(Phonon::State, Phonon::State)),this,SLOT(stateChanged(Phonon::State, Phonon::State)));
   connect(vd.vw,SIGNAL(mousePressed(Qt::MouseButton,int)),this,SLOT(on_Source_mousePressed(Qt::MouseButton,int)));
   connect(vd.vw,SIGNAL(mouseMoved(int)),this,SLOT(on_Source_mouseMoved(int)));

}

void MainWindow::on_pushButton_LoadSource_clicked()
{
    //<signal;file.dat><video;file.avi><signal;file2.dat>
   //printf("Loading sources: %s\n",ui->lineEdit_Source->toPlainText().toStdString().c_str());

   SOURCEFILES src;
   int rv = ParseSourceString(ui->lineEdit_Source->toPlainText().toStdString(),src);
   if(rv!=0)
   {
      QString str;
      str.sprintf("Error number %d",rv);
      QMessageBox::information(this,"Syntaxt error in layout string",str);
      return;
   }


   /*printf("Signal sources:\n");
   for(int i=0;i<src[1].size();i++)
      printf("- %s\n",src[1][i].c_str());*/

   // Loading sources
   SignalData.clear();

   std::vector<std::vector<int> > v;
   int ok;
   bool anyerr=false;
   QString err;
   for(unsigned i=0;i<src[1].size();i++)
   {
      v = LoadSignalFile(src[1][i],ok);
      // Add a source:
      //printf("Add a source %d %s, ok: %d. Returned vector size: %d\n",i,src[1][i].c_str(),ok,v.size());
      if(ok==0 && v.size()!=0)
      {
         SIGNALDATA sd;
         sd.data = v;
         sd.centersample=0;
         sd.filename=QString(src[1][i].c_str());
         SignalData.push_back(sd);
      }
      else
      {
         if(ok==-1)
            err=QString("Cannot load %1: file not found.").arg(src[1][i].c_str());
         else
            err=QString("Cannot load %1: invalid file format.").arg(src[1][i].c_str());
         anyerr=true;
         break;
      }
   }
   // If there has been any error loading a file, deactivate the views, and return.
   if(anyerr)
   {
      SignalData.clear();
      QMessageBox::critical(this,"Load source",err+QString("\n\nData sources are discarded. Check source definitions and file format."));
      SetupViews("");
      return;
   }



   // Re-interpret the views

   SetupViews(ui->lineEdit_View->toPlainText().toStdString());
   AdjustSignalViewSlider();

   // Clear all the backup.
   SignalDataUndo.clear();
   RefPointsUndo.clear();
   SetUndoable(false);


   // Load the videos
   //printf("Delete video views\n");
   DeleteVideoViews();
   for(unsigned i=0;i<src[0].size();i++)
   {
      //printf("Add video %s\n",src[0][i].c_str());
      addVideo(QString(src[0][i].c_str()));
   }

   // Prune the reference points to make sure none refers to unavailable source.
   QString str;
   RefPoints=PruneRefPoints(RefPoints,str);
   SetReferencePoints(RefPoints);
   RefDialog->ClearLinks();


   // Update the splitter
   QList<int> s;
   if(VideoViewData.size())
      s.push_back(1);
   else
      s.push_back(0);
   if(ViewData.size())
      s.push_back(1);
   else
      s.push_back(0);
   signalVideoSplitter->setSizes(s);



}
int MainWindow::ParseSourceString(string str,SOURCEFILES &src)
{
   src.clear();
   src.resize(2);


   // Regexp for layout string:
   // Characters ;<> are excluded in the match of the expression for syntax checking.
   // Group 0: whole expression
   // Group 1: source type
   // Group 2: source file
   // Validation of the whole string: look for multiple expressions with a '(expression)*' regex string.
   string expression = string("\\s*<\\s*([^;^>^<]*)\\s*;\\s*([^;^>^<]*)\\s*>\\s*");

   QRegExp e(QString(expression.c_str()));
   //printf("e.isValid: %d\n",(int)e.isValid());
   //printf("e.isValid: %s\n",e.errorString().toStdString().c_str());
   string expression2=string("(")+expression+string(")*");
   QRegExp validation(QString(expression2.c_str()));
   //printf("validation.isValid: %d\n",(int)validation.isValid());
   //printf("validation.isValid: %s\n",e.errorString().toStdString().c_str());


   // Validation
   int iin=validation.exactMatch(QString(str.c_str()));
   if(iin==-1)
   {
      //printf("Validation match failed\n");
      return -5;
   }


   // Expression parsing
   e.indexIn(QString(str.c_str()));
   unsigned midx=0;
   int pos = 0;
   while((pos = e.indexIn(QString(str.c_str()), pos)) != -1)
   {
      pos += e.matchedLength();

      //printf("Capture group %d\n",midx);
      //printf("NumCaptures: %d\n",e.numCaptures());
      for(int i=0;i<e.numCaptures()+1;i++)
         //printf("Capture %d: %s\n",i,e.cap(i).toStdString().c_str());


      if(e.numCaptures()!=2)
      {
         //cout << "Invalid match size\n";
         return -9;
      }


      string sourcetype = e.cap(1).toStdString();
      if(sourcetype.compare("video")!=0 && sourcetype.compare("signal")!=0)
      {
         //cout << "Invalid source type\n";
         return -10;
      }
      string sourcefile = e.cap(2).toStdString();

      if(sourcetype.compare("video")==0)
         src[0].push_back(sourcefile);
      else
         src[1].push_back(sourcefile);


      midx++;
   }
   return 0;
}


/**
  \brief Load a data source from a file. Return format: data[channel][samples]

  rv: return value.
      0: success
      -1: file not found
      -2: invalid file content

   Parses signed integers space or tab separated. Handles special entries of the form 'NaN' and replaces them by zeroes.
**/
std::vector<std::vector<int> > MainWindow::LoadSignalFile(string file,int &rv, bool report)
{
   std::vector<std::vector<int> > data;

   rv=0;

   std::vector<int> d;
   bool first=true;

   QFile filein(QString(file.c_str()));
   int line=0;
   if (filein.open(QIODevice::ReadOnly))
   {
      QByteArray filedata = filein.readAll();
      bool ok;
      data = parse(filedata.data(),ok);
      if(!ok)
      {
         rv=-2;
         return data;
      }

   }
   else
   {
      rv=-1;
      return data;
   }

   return data;
}

/**
  \brief Slot handling mouse button press in a scope or video view. Find view and pass to ViewClick
**/
void MainWindow::on_Source_mousePressed(Qt::MouseButton button, int samplex)
{
   // Find which view has triggered the message.
   QObject *s = sender();
   for(unsigned i=0;i<ViewData.size();i++)
   {

      if(ViewData[i].scope == s)
      {
         SourceClick(SID2IDX(ViewData[i].source),button,samplex);    // Convert signal to absolude ID
         SetSBLabelPointer(SID2IDX(ViewData[i].source));
         return;
      }
   }
   // Not a scope, a video?
   for(int i=0;i<ViewData.size();i++)
   {
      if(VideoViewData[i].vw == s)
      {
         SourceClick(VID2IDX(i),button,samplex);
         SetSBLabelPointer(VID2IDX(i));
         return;
      }
   }
}
/**
  \brief Slot handling mouse move press in a scope or video view.
**/
void MainWindow::on_Source_mouseMoved(int samplex)
{
   int view=-1;
   QObject *s = sender();
   for(int i=0;i<ViewData.size();i++)
   {
      if(ViewData[i].scope == s)
      {
         view=SID2IDX(ViewData[i].source);
         break;
      }
   }
   if(view==-1)   // it must be a video
   {
      for(unsigned i=0;i<VideoViewData.size();i++)
      {
         if(VideoViewData[i].vw == s)
         {
            view=VID2IDX(i);
            break;
         }
      }
   }
   assert(view!=-1);

   QString str;
   if(IsIdxSignal(view))
      str.sprintf("Pointer position: %d",samplex);
   else
      str.sprintf("-");
   SB_LabelPosition->setText(str);
   SetSBLabelPointer(view);
}

/**
  \brief Handles mouse button click
  source: IDX of the source.
**/
void MainWindow::SourceClick(int source,Qt::MouseButton button,int samplex)
{
   if(button==Qt::RightButton)
   {
      // Handle primary/secondary selection
      if(GetPrimarySource()==-1 && source!=source_secondary)    // if no primary selected, and we didn't click on a secondary...
         source_primary=source;                             // ... set selected source as primary
      else
      {
         if(source==GetPrimarySource())                         // we might have clicked on a primary - it will become a secondary...
         {
            source_secondary=source;
            source_primary=-1;
         }
         else
         {
            if(source==source_secondary)                    // we might have clicked on a secondary - it will be deselected
            {
               source_secondary=-1;
            }
            else
               source_secondary=source;                     // we have clicked on an unselected source but there is a primary
         }
      }

      VisualizePrimarySecondary();
   }
   if(button==Qt::LeftButton && IsIdxSignal(source))
   {
      // Center source on location
      if(samplex>=0 && samplex<SignalData[IDX2SID(source)].data[0].size())
      {
         on_Source_Slided(source,samplex);
      }
   }
}



/**
  \brief Visualize the primary and secondary sources by highlighting the respective scopes, and update the status bar.

**/
void MainWindow::VisualizePrimarySecondary()
{
   // Highlight the primary and secondary.

   QString s1,s2;
   s1 = QString("Pri: %1").arg(GetPrimarySource()==-1?QString("-"):IsIdxSignal(GetPrimarySource())?QString("S%1").arg(IDX2SID(GetPrimarySource())):QString("V%1").arg(IDX2VID(GetPrimarySource())));
   s2 = QString("Sec: %1").arg(source_secondary==-1?QString("-"):IsIdxSignal(source_secondary)?QString("S%1").arg(IDX2SID(source_secondary)):QString("V%1").arg(IDX2VID(source_secondary)));
   SB_LabelSource->setText(s1+QString(" ")+s2);



   for(int i=0;i<ViewData.size();i++)
   {
      QPalette palette;
      if(SID2IDX(ViewData[i].source) == GetPrimarySource())
      {
         palette.setColor(ViewData[i].frame->backgroundRole(), QColor(0,0,255));
         ViewData[i].frame->setPalette(palette);
         //ViewData[i].frame->setBackgroundRole(QPalette::Link);
      }
      else
      {
         if(SID2IDX(ViewData[i].source) == source_secondary)
         {
            palette.setColor(ViewData[i].frame->backgroundRole(), QColor(255,0,255));
            ViewData[i].frame->setPalette(palette);
            //ViewData[i].frame->setBackgroundRole(QPalette::LinkVisited);
         }
         else
         {
            ViewData[i].frame->setPalette(palette);
            ViewData[i].frame->setBackgroundRole(QPalette::Window);
         }
      }
   }
   for(unsigned i=0;i<VideoViewData.size();i++)
   {
      QPalette palette;
      if(VID2IDX(i) == GetPrimarySource())
      {
         palette.setColor(VideoViewData[i].frame->backgroundRole(), QColor(0,0,255));
         VideoViewData[i].frame->setPalette(palette);

         //VideoViewData[i].frame->setBackgroundRole(QPalette::Link);
      }
      else
      {
         if(VID2IDX(i) == source_secondary)
         {
            palette.setColor(VideoViewData[i].frame->backgroundRole(), QColor(255,0,255));
            VideoViewData[i].frame->setPalette(palette);
            //VideoViewData[i].frame->setBackgroundRole(QPalette::LinkVisited);
         }
         else
         {
            VideoViewData[i].frame->setPalette(palette);
            VideoViewData[i].frame->setBackgroundRole(QPalette::Window);
         }
      }
   }
}


void MainWindow::SetSBLabelPointer(int idx)
{
   QString str1="Source under pointer: ";
   QString str2;
   if(IsIdxSignal(idx))
   {
      str1+=QString("S%1").arg(ViewData[IDX2SID(idx)].source);
      str2=QString("Center sample: %1").arg(SignalData[ViewData[IDX2SID(idx)].source].centersample);
   }
   else
   {
      str1+=QString("V%1").arg(IDX2VID(idx));
      str2=QString("Frame time: %1").arg(VideoViewData[IDX2VID(idx)].mo->currentTime());
   }

   SB_LabelSignal->setText(str1);
   SB_LabelCenter->setText(str2);
}

/**
  \brief returns the center sample, or the current video timecode, corresponding to source idx

   flag effective only applies to video. When true, returns the current, visible, video position.
   When false, returns 'centersample'. Used when scrolling linked sources to ensure smoothness of scrolling.
**/
unsigned MainWindow::GetCenterSample(int idx,bool effective)
{
   if(idx<VideoViewData.size())
   {
      // idx is a video index
      if(effective)
         return VideoViewData[idx].mo->currentTime();
      else
         return VideoViewData[idx].centersample;
   }
   return SignalData[idx-VideoViewData.size()].centersample;
}
void MainWindow::SetCenterSample(int idx,int centersample)
{
   if(IsIdxVideo(idx))
      // idx is a video index
      VideoViewData[IDX2VID(idx)].centersample=centersample;
   else
      SignalData[IDX2SID(idx)].centersample=centersample;
}
/**
  \brief Add a reference point between a primary and a secondary.
**/
void MainWindow::on_AddReference()
{
   if(GetPrimarySource()!=-1 && source_secondary!=-1)
   {
      // Both sources are selected -> we add a reference
      std::vector<int> v(4);
      v[0] = GetPrimarySource();
      v[1] = GetCenterSample(source_primary);
      v[2] = source_secondary;
      v[3] = GetCenterSample(source_secondary);
      RefPoints.push_back(v);
      SetReferencePoints(RefPoints);
   }
}
void MainWindow::on_RemoveReference(int idx)
{
   if(idx>=0)
      RefPoints.erase(RefPoints.begin()+idx);
   else
      RefPoints.clear();
   SetReferencePoints(RefPoints);
}

/**
  \brief Reponds to changes in the signal relations linking

  Mirrors the active relation and global activation flag locally.
**/
void MainWindow::on_ChangedActiveRelations()
{
   UpdateRelationsActive();
}
void MainWindow::UpdateRelationsActive()
{
   RelationsActive = RefDialog->GetRelationsActive();
   // Need to patch RelationsActive to copy the regression equation (i.e. the reference point dialog box only holds the src/dst relations, not the equation
   for(unsigned i=0;i<RelationsActive.size();i++)
   {
      for(RELATIONS::iterator it = RelationsAvailable.begin();it!=RelationsAvailable.end();it++)
      {
         if(it->x1==RelationsActive[i].x1 && it->x2==RelationsActive[i].x2)
         {
            RelationsActive[i].a = it->a;
            RelationsActive[i].b = it->b;
            continue;
         }
      }
   }

   LinkSignals = RefDialog->GetLinkState();
}







void MainWindow::on_ReferenceSelected(int idx)
{
   // Highlight the primary and secondary
   source_primary=RefPoints[idx][0];
   source_secondary=RefPoints[idx][2];

   // Set to center position
   SetCenterSample(source_primary,RefPoints[idx][1]);
   SetCenterSample(source_secondary,RefPoints[idx][3]);

   SetAllSliderPosition();
   VisualizePrimarySecondary();
}


/**
   \brief Load program configuration
**/

void MainWindow::on_actionLoad_configuration_triggered()
{
   QString fileName = QFileDialog::getOpenFileName(this, "Load Configuration",QString(),"Configuration (*.xml)");
   if(!fileName.isNull())
   {
      QFileInfo fi(fileName);
      //printf("absolute path: %s\n",fi.absolutePath().toStdString().c_str());
      path.setCurrent(fi.absolutePath());
      loadConfiguration(fileName);
   }
}

/**
  \brief Save program configuration
**/
void MainWindow::on_actionSave_configuration_triggered()
{
   QString fileName = QFileDialog::getSaveFileName(this, "Save Configuration",QString(),"Configuration (*.xml)");
   if(!fileName.isNull())
   {
      QFile file(fileName);
      if (file.open(QIODevice::WriteOnly | QIODevice::Text | QIODevice::Truncate))
      {
         QXmlStreamWriter xml(&file);
         xml.setAutoFormatting(true);
         xml.writeStartDocument();
         // Start configuration
         xml.writeStartElement("Configuration");

         // Main-related itms
         xml.writeStartElement("Main");
         xml.writeAttribute("Source",ui->lineEdit_Source->toPlainText());
         xml.writeAttribute("View",ui->lineEdit_View->toPlainText());
         xml.writeEndElement();

         // Reference related items
         xml.writeStartElement("References");
         for(int i=0;i<RefPoints.size();i++)
         {
            QString str;
            str.sprintf("relation%d",i);
            xml.writeStartElement("ReferenceData");
            xml.writeAttribute("source1",QString("%1").arg(RefPoints[i][0]));
            xml.writeAttribute("position1",QString("%1").arg(RefPoints[i][1]));
            xml.writeAttribute("source2",QString("%1").arg(RefPoints[i][2]));
            xml.writeAttribute("position2",QString("%1").arg(RefPoints[i][3]));
            xml.writeEndElement();
         }

         xml.writeEndElement();  // References

         xml.writeEndElement();  // Configuration

         xml.writeEndDocument();
         file.close();
      }
      else
      {
         QMessageBox::critical(this, "Save configuration error", "Cannot write to file");
      }
   }
}


void MainWindow::loadConfiguration(QString fileName)
{
   QFile file(fileName);
   if (file.open(QIODevice::ReadOnly | QIODevice::Text))
   {
      RefPoints.clear();

      QXmlStreamReader xml(&file);
      while (!xml.atEnd())
      {
         QXmlStreamReader::TokenType type = xml.readNext();
         //printf("readNext type: %d\n",type);
         if(type==QXmlStreamReader::StartElement)
         {
            //printf("name: %s\n",xml.name().toString().toStdString().c_str());
            //printf("namespaceUri: %s\n",xml.namespaceUri().toString().toStdString().c_str());
            if(xml.name().toString().compare("Main")==0)
            {
               QXmlStreamAttributes at = xml.attributes();
               QString src = at.value("Source").toString();
               QString vw = at.value("View").toString();
               //printf("src: %s\n",src.toStdString().c_str());
               //printf("view: %s\n",vw.toStdString().c_str());
               if(!src.isNull())
                  ui->lineEdit_Source->setPlainText(src);
               else
                  ui->lineEdit_Source->setPlainText("");
               if(!vw.isNull())
                  ui->lineEdit_View->setPlainText(vw);
               else
                  ui->lineEdit_View->setPlainText("");
            }
            if(xml.name().toString().compare("ReferenceData")==0)
            {


               QXmlStreamAttributes at = xml.attributes();
               QString s1 = at.value("source1").toString();
               QString v1 = at.value("position1").toString();
               QString s2 = at.value("source2").toString();
               QString v2 = at.value("position2").toString();

               vector<int> r(4);

               r[0] = s1.toInt();
               r[1] = v1.toInt();
               r[2] = s2.toInt();
               r[3] = v2.toInt();

               RefPoints.push_back(r);

            }
         }
      }
      file.close();

      // Effect the loaded configuration
      REFERENCEPOINTS emptyref;
      RefDialog->SetReferencePoints(emptyref);
      on_pushButton_LoadSource_clicked();    // Load source automatically applies the view
      //on_pushButton_ApplyView_clicked();
      // Set the reference points
      RefDialog->SetReferencePoints(RefPoints);
   }
   else
   {
      QMessageBox::critical(this, "Load configuration error", "Cannot read from file");
   }
}

/**
  \brief Export the link equation as text
**/
void MainWindow::on_actionText_triggered()
{
   QString t="Save relation ";
   QString fileName = QFileDialog::getSaveFileName(this, t+"as text",QString(),"Text (*.txt)");
   if(!fileName.isNull())
   {
      QFile file(fileName);
      if (file.open(QIODevice::WriteOnly | QIODevice::Text | QIODevice::Truncate))
      {
         // Stream writer...
         QTextStream out(&file);

         for(int i=0;i<RelationsAvailable.size();i++)
         {
            QString eq = RelationToText(RelationsAvailable[i]);
            out << eq << endl;
         }
        file.close();
      }
      else
      {
         QMessageBox::critical(this,t+"error", "Cannot write to file");
      }
   }
}



/**
  \brief Export the link equation as a matrix
**/
void MainWindow::on_actionMatrix_triggered()
{
   QString t="Save relation ";
   QString fileName = QFileDialog::getSaveFileName(this, t+"as matrix",QString(),"Text (*.txt)");
   if(!fileName.isNull())
   {
      QFile file(fileName);
      if (file.open(QIODevice::WriteOnly | QIODevice::Text | QIODevice::Truncate))
      {
         // Stream writer...
         QTextStream out(&file);

         for(int i=0;i<RelationsAvailable.size();i++)
         {
            out << RelationsAvailable[i].x1 << " " << RelationsAvailable[i].x2 << " " << RelationsAvailable[i].b << " " << RelationsAvailable[i].a << endl;
         }
        file.close();
      }
      else
      {
         QMessageBox::critical(this,t+"error", "Cannot write to file");
      }
   }
}


/**
  \brief Resamples sigdataorg with the resample factor. resample < 1.0. FrqOld/FrqNew = resample.
**/
SIGNALDATA MainWindow::ResampleSignalData(SIGNALDATA &sigdataorg,double resample,int padleft,int padright)
{
   printf("MainWindow::ResampleSignalData m: %lf padleft: %d\n",resample,padleft);
   SIGNALDATA sigdat;

   printf("sigdataorg number of channels: %d\n",sigdataorg.data.size());
   printf("sigdataorg channel size: %d\n",sigdataorg.data[0].size());

   sigdat.filename = sigdataorg.filename+"_res";
   sigdat.centersample=sigdataorg.centersample;

   sigdat.data.resize(sigdataorg.data.size());                    // Set number of channels
   for(int c=0;c<sigdataorg.data.size();c++)                      // Iterate channels
   {
      // Resize channel
      int newsize = (int)ceil((((double)sigdataorg.data[0].size()) / resample));             // Round up to be consistent with matlab resample
      printf("Channel %d newsize w/o pad %d newsize w/ pad: %d\n",c,newsize,newsize+padleft);

      sigdat.data[c].resize(newsize+padleft+padright,0);
      for(int i=0;i<newsize;i++)                    // Iterate the samples
      {
         double srcidx;
         srcidx = resample*(double)i;
         sigdat.data[c][padleft+i] =  sigdataorg.data[c][(int)srcidx];
      }
   }
   return sigdat;
}

/**
  \brief Computes the resample actions to execute

   Returns a map linking a source (first) to a resample relation (second, RESAMPLEREL)
   The resample relation includes:
   - the resample ratio (second.m)
   - the (optional) offset to prepend (second.o). If not used, it is set to 0
   - the optional padding at the enf of the signal (second.p). If not used, it is set to 0.

**/
map<int,RESAMPLEREL> MainWindow::ResampleLogic(vector<RELATIONS> Graphs, bool prepend)
{

   map<int,RESAMPLEREL> allm;
   printf("------------------------void ResampleLogic(vector<RELATIONS> Graphs) prepend: %d\n",prepend);
   for(int i=0;i<Graphs.size();i++)
   {
      RELATIONS RelationsFollowed = Graphs[i];
      printf("**** Graph %d ****\n",i);

      // If pure video graph, skip.
      bool purevid=true;
      int numsig=0;
      for(int i=0;i<RelationsFollowed.size();i++)
      {
         if(IsIdxSignal(RelationsFollowed[i].x1) || IsIdxSignal(RelationsFollowed[i].x2))
         {
            purevid=false;
         }
         if(IsIdxSignal(RelationsFollowed[i].x1))
            numsig++;
         if(IsIdxSignal(RelationsFollowed[i].x2))
            numsig++;
      }
      if(purevid==true)
      {
         printf("This is a pure video graph, skip it\n");
         continue;
      }
      // If the graph has only 1 signal edge (eg. if the only link is between a video and a signal) no resampling is possible.
      if(numsig<2)
      {
         printf("This graph has only one signal edge, no resampling possible, skip\n");
         continue;
      }



      // m holds a relative set of relations within the graph, with the first edge of the first relation as the start point
      map<int,RESAMPLEREL> m;

      m.clear();
      m[RelationsFollowed[0].x1].m=1.0;
      m[RelationsFollowed[0].x1].o=0.0;

      //printf("Relations followed: \n");

      for(int i=0;i<RelationsFollowed.size();i++)
      {
         m[RelationsFollowed[i].x2].m = m[RelationsFollowed[i].x1].m * RelationsFollowed[i].b;
         m[RelationsFollowed[i].x2].o = m[RelationsFollowed[i].x1].o * RelationsFollowed[i].b + RelationsFollowed[i].a;
         //printf("x%d->x%d\n",RelationsFollowed[i].x1,RelationsFollowed[i].x2);
      }

      printf("Signal - RelFrq  RelOffset\n");
      for(map<int,RESAMPLEREL>::iterator it=m.begin();it!=m.end();it++)
      {
         printf("%d - %lf %lf\n",it->first,it->second.m,it->second.o);
      }


      // Here should identify the highest frequency, and relate everything to the highest frequency
      // Find highest value to normalize by it.
      // Exploits relations going through a video edge, but does not take into account the video in determining the highest frequency.
      double hv;
      int hfsrc;
      bool first;
      first=true;
      for(map<int,RESAMPLEREL>::iterator it=m.begin();it!=m.end();it++)
      {
         if(IsIdxVideo(it->first))
            continue;
         if(first)
         {
            hv = it->second.m;
            hfsrc = it->first;
            first=false;
         }
         else
         {
            if(it->second.m>hv)
            {
               hv=it->second.m;
               hfsrc = it->first;
            }
         }
      }
      //printf("Highest sample rate hv: %lf. hf source: %d\n",hv,hfsrc);
      // Normalize frequency
      for(map<int,RESAMPLEREL>::iterator it=m.begin();it!=m.end();it++)
      {
         it->second.m/=hv;
         it->second.o/=it->second.m;
      }
      printf("Signal - NormRelFrq  NormRelOffset\n");
      for(map<int,RESAMPLEREL>::iterator it=m.begin();it!=m.end();it++)
      {
         printf("%d - %lf %lf\n",it->first,it->second.m,it->second.o);
      }

      // Look for the leftmost signal, skipping the video in determining this
      double lm;
      int lmsrc;
      first=true;
      for(map<int,RESAMPLEREL>::iterator it=m.begin();it!=m.end();it++)
      {
         if(IsIdxVideo(it->first))
            continue;
         if(first)
         {
            lm = it->second.o;
            lmsrc = it->first;
            first=false;
         }
         else
         {
            if(it->second.o>lm)
            {
               lm=it->second.o;
               lmsrc = it->first;
            }
         }
      }
      //printf("Left most sample: %lf. lm source: %d\n",lm,lmsrc);
      // Convert o from leftmost sample to pad left offset (offset=maxo-o). Handles the prepen
      for(map<int,RESAMPLEREL>::iterator it=m.begin();it!=m.end();it++)
      {
         if(prepend)
            it->second.o = (int)(lm-it->second.o);
         else
            it->second.o = 0;
      }

      // Compute the new length of the signals for this graph, including the offset
      // Find the length of the longest resampled signal with matlab and C resample variants
      // Skips video
      printf("Compute new length\n");
      int maxl_c=0;
      int maxl_matlab=0;
      for(map<int,RESAMPLEREL>::iterator it=m.begin();it!=m.end();it++)
      {
         if(IsIdxVideo(it->first))
            continue;
         int cl;
         // Matlab
         int n,d;
         DoubleToRatio(1.0/it->second.m,n,d);
         cl = it->second.o + ceil((double)SignalData[IDX2SID(it->first)].data[0].size()*(double)n/(double)d);
         it->second.l_matlab = cl;
         if(cl>maxl_matlab)
            maxl_matlab=cl;
         // C
         cl = it->second.o + ceil((double)SignalData[IDX2SID(it->first)].data[0].size()/it->second.m);
         it->second.l_c = cl;
         if(cl>maxl_c)
            maxl_c=cl;
      }

      // set the padding right size
      printf("set the padding right size\n");
      for(map<int,RESAMPLEREL>::iterator it=m.begin();it!=m.end();it++)
      {
         it->second.p_matlab = maxl_matlab-it->second.l_matlab;
         it->second.p_c = maxl_c-it->second.l_c;
      }


      // This means
      for(map<int,RESAMPLEREL>::iterator it=m.begin();it!=m.end();it++)
      {
         printf("Src %d prepad %lf. NL C/Matlab: %d/%d. Postpend C/Matlab: %d/%d\n",it->first,lm-it->second.o,it->second.l_c,it->second.l_matlab,it->second.p_c,it->second.p_matlab);
      }

      // Go through all the relations and erase those that aren't signals
      map<int,RESAMPLEREL> m2;
      for(map<int,RESAMPLEREL>::iterator it=m.begin();it!=m.end();it++)
      {
         if(IsIdxSignal(it->first))
            m2[it->first]=it->second;
      }

      printf("after pruning\n");
      for(map<int,RESAMPLEREL>::iterator it=m2.begin();it!=m2.end();it++)
      {
         printf("Src %d prepad %lf. NL C/Matlab: %d/%d. Postpend C/Matlab: %d/%d\n",it->first,lm-it->second.o,it->second.l_c,it->second.l_matlab,it->second.p_c,it->second.p_matlab);
      }

      // End of a graph, we keep the relations in allm.
      allm.insert(m2.begin(),m2.end());

   }
   printf("DUMPING all resample relations. Total %d.\n",allm.size());
   for(map<int,RESAMPLEREL>::iterator it = allm.begin();it!=allm.end();it++)
   {
      printf("signal %d. m: %lf. o: %lf\n",it->first,it->second.m,it->second.o);
   }


   return allm;
}

/**
  \brief Resample in-place
**/
void MainWindow::ResampleInPlace(map<int,RESAMPLEREL> m,bool prepend,bool postpend)
{
   printf("MainWindow::ResampleInPlace; prepend %d postpend %d\n",prepend,postpend);
   // Iterate all the source in the relation, resample them, and add them to the visualization stuff.
   for(map<int,RESAMPLEREL>::iterator it=m.begin();it!=m.end();it++)
   {
      printf("Resampling source %d (%s)\n",it->first,SignalData[IDX2SID(it->first)].filename.toStdString().c_str());
      if(!IsIdxSignal(it->first))
      {
         printf("Source %d is not a signal, skipping\n",it->first);
         continue;
      }

      // In principle magnitude is <= 1 - what happens if not?
      assert(it->second.m<=1.0);



      // This is already done by the resample logic
      double o;
      o=it->second.o;
      /*if(prepend)
         o=it->second.o;
      else
         o=0;*/
      int p;
      if(postpend)
         p=it->second.p_c;
      else
         p=0;
      printf("Calling ResampleSignalData; factor %lf offset %d postpend %d\n",it->second.m,o,p);
      SIGNALDATA sigdat = ResampleSignalData(SignalData[IDX2SID(it->first)],it->second.m,o,p);

      // In-place resample
      printf("store\n");
      SignalData[IDX2SID(it->first)] = sigdat;

      // Update the reference points accordingly
      printf("upd ref points\n");
      for(REFERENCEPOINTS::iterator r=RefPoints.begin();r!=RefPoints.end();r++)
      {
         if((*r)[0] == it->first)
            (*r)[1] = (int)(((double)(*r)[1])/it->second.m+o);
         if((*r)[2] == it->first)
            (*r)[3] = (int)(((double)(*r)[3])/it->second.m+o);
      }
   }
   RefDialog->SetReferencePoints(RefPoints);             // Update GUI with reference points
   ComputeRelations();                                   // Update GUI with relations
}
void MainWindow::ResampleMatlab(map<int,RESAMPLEREL> m,bool nn,bool prepend,bool postpend)
{
   QString matlabcode;
   QString str;

   matlabcode.sprintf("\% Matlab resample code\n");

   for(map<int,RESAMPLEREL>::iterator it=m.begin();it!=m.end();it++)
   {
      str.sprintf("\% Resampling signal %d (%s). Length: %d. Sample rate ratio: %lf. Prepend offset: %lf\n",it->first,SignalData[it->first].filename.toStdString().c_str(),SignalData[it->first].data[0].size(),it->second.m,it->second.o);
      matlabcode+=str;
   }

   matlabcode+="% input files\n";
   matlabcode+="fin={\n";
   QDir dir;
   for(map<int,RESAMPLEREL>::iterator it=m.begin();it!=m.end();it++)
      matlabcode+="\t'"+ dir.cleanPath(dir.absoluteFilePath(SignalData[IDX2SID(it->first)].filename)) +"'\n";
   matlabcode+="};\n";
   matlabcode+="fout={\n";
   for(map<int,RESAMPLEREL>::iterator it=m.begin();it!=m.end();it++)
      matlabcode+="\t'"+ dir.cleanPath(dir.absoluteFilePath(SignalData[IDX2SID(it->first)].filename)) +".res"+"'\n";
   matlabcode+="};\n";
   matlabcode+="sr_p=[\n";
   for(map<int,RESAMPLEREL>::iterator it=m.begin();it!=m.end();it++)
   {
      int n,d;
      DoubleToRatio(1.0/it->second.m,n,d);
      matlabcode+=QString("\t%1\n").arg(n);
   }
   matlabcode+="];\n";
   matlabcode+="sr_q=[\n";
   for(map<int,RESAMPLEREL>::iterator it=m.begin();it!=m.end();it++)
   {
      int n,d;
      DoubleToRatio(1.0/it->second.m,n,d);
      matlabcode+=QString("\t%1\n").arg(d);
   }
   matlabcode+="];\n";

   if(prepend)
   {
      matlabcode+="o=[\n";
      for(map<int,RESAMPLEREL>::iterator it=m.begin();it!=m.end();it++)
         matlabcode+=QString("\t%1\n").arg(it->second.o);
      matlabcode+="];\n";
   }

   if(postpend)
   {
      matlabcode+="p=[\n";
      for(map<int,RESAMPLEREL>::iterator it=m.begin();it!=m.end();it++)
      {
         matlabcode+=QString("\t%1\n").arg(it->second.p_matlab);
      }
      matlabcode+="];\n";
   }

   matlabcode+=QString("for i=1:%1\n").arg(m.size());
   matlabcode+=QString("\tx = load(fin{i});\n");
   matlabcode+=QString("\ty = resample(x,sr_p(i),sr_q(i)");       // resample
   if(nn)
      matlabcode+=QString(",0");                                  // nearest neighbor
   matlabcode+=QString(");\n");

   if(prepend)
   {
      matlabcode+=QString("\tz = zeros(o(i),size(x,2));\n");
      matlabcode+=QString("\ty = [z;y];\n");                            // prepend 0
   }
   if(postpend)
   {
      matlabcode+=QString("\tz = zeros(p(i),size(x,2));\n");
      matlabcode+=QString("\ty = [y;z];\n");                            // postpend 0
   }
   matlabcode+=QString("\tsize(x)\n");
   matlabcode+=QString("\tsize(y)\n");
   matlabcode+=QString("\tsave(fout{i},'y','-ascii');\n");
   matlabcode+=QString("end\n");


   MatlabCodeDialog *mdlg = new MatlabCodeDialog(this);
   mdlg->setCode(matlabcode);
   mdlg->exec();
   delete mdlg;
}

/**
  \brief Save reference points
**/
void MainWindow::on_actionSave_reference_points_triggered()
{
   QString fileName = QFileDialog::getSaveFileName(this, "Save Reference Points",QString(),"Text (*.txt)");
   if(!fileName.isNull())
   {
      QFile file(fileName);
      if (file.open(QIODevice::WriteOnly | QIODevice::Text | QIODevice::Truncate))
      {
         QTextStream out(&file);

         for(int i=0;i<RefPoints.size();i++)
         {
            //QString eq = RelationToText(RelationsAvailable[i]);
            for(int j=0;j<4;j++)
               out << RefPoints[i][j] << " ";
            out << endl;
         }
         file.close();
      }
      else
      {
         QMessageBox::critical(this, "Save error", "Cannot write to file");
      }
   }
}


/**
  \brief Prune the reference points that refer to unavailable sources. Returns only the valid reference points, and a displayable error message.
**/
REFERENCEPOINTS MainWindow::PruneRefPoints(REFERENCEPOINTS v,QString &str,bool display)
{
   REFERENCEPOINTS vv;
   int err=0;

   for(int i=0;i<v.size();i++)
   {
      if(v[i][0]>=GetNumSources() || v[i][2]>=GetNumSources())
         err++;
      else
      {
         if(v[i][0]==v[i][2])
            err++;
         else
            vv.push_back(v[i]);
      }
   }
   if(err)
      str=QString("%1 reference points relate to nonexistant sources. They will be discarded.").arg(err);

   if(display && err)
      QMessageBox::information(this,"Reference points",str);

   return vv;
}


/**
  \brief Set the reference points to ref, and handles UI and relation computation update
**/
void MainWindow::SetReferencePoints(REFERENCEPOINTS ref)
{
   // Store the the new reference points
   RefPoints=ref;
   // Set the reference points
   RefDialog->SetReferencePoints(RefPoints);
   // Compute the links
   ComputeRelations();
}

/**
  \brief Load reference points
**/

void MainWindow::on_actionLoad_reference_points_triggered()
{
   QString strtitle("Loading reference points");
   QString fileName = QFileDialog::getOpenFileName(this, "Load Reference Points",QString(),"text (*.txt)");
   if(!fileName.isNull())
   {
      std::vector<std::vector<int> > v;
      int ok;
      v = LoadSignalFile(fileName.toStdString(),ok);
      if(ok<0)
      {
         if(ok==-1)
            QMessageBox::critical(this,QString("Load reference points"),QString("Can't load %1. File not found.").arg(fileName));
         else
            QMessageBox::critical(this,QString("Load reference points"),QString("Can't load %1. Invalid file content.").arg(fileName));
         return;
      }

      if(v.size()!=4)
      {
         QMessageBox::critical(this,strtitle,"Invalid file format; expecting 4 columns");
         return;
      }
      // Iterate through all
      int err=0;

      // Convert the loaded format into the referencepoint format
      REFERENCEPOINTS rp,vrp;
      for(int i=0;i<v[0].size();i++)
      {
         vector<int> p(4,0);
         p[0]=v[0][i];
         p[1]=v[1][i];
         p[2]=v[2][i];
         p[3]=v[3][i];
         rp.push_back(p);
      }


      // Check the reference points to make sure they are valid, issuing an error message in case of errors.
      QString str;
      vrp = PruneRefPoints(rp,str);
      SetReferencePoints(vrp);
   }
}

/**
  \brief Shows the loaded signal sources
**/
void MainWindow::on_actionShow_available_sources_triggered()
{
   SourceDialog *dlg = new SourceDialog(this);
   dlg->SetSignalData(SignalData);
   dlg->exec();
   delete dlg;

}



void MainWindow::on_actionAbout_Q_triggered()
{
    QApplication::aboutQt();
}



/**
  \brief If there is a primary source selected prompts the user for a file name in which to save the source.
**/
void MainWindow::on_actionSave_primary_source_triggered()
{
   QString strtitle="Save primary source";

   if(GetPrimarySource()==-1 || !IsIdxSignal(GetPrimarySource()))
   {
      QMessageBox::critical(this,strtitle,"No primary signal source is selected. Select the primary signal source first.");
   }
   else
   {
      SaveSignal(SignalData[IDX2SID(GetPrimarySource())].data,strtitle);
   }
}

/**
  \brief Save a signal in text mode.
**/
void MainWindow::SaveSignal(vector<vector<int> > &source,QString strtitle)
{
   QString fileName = QFileDialog::getSaveFileName(this,strtitle,QString(),"Text (*.txt);;All (*.*)");
   if(!fileName.isNull())
   {
      QFile file(fileName);
      if (file.open(QIODevice::WriteOnly | QIODevice::Text | QIODevice::Truncate))
      {
         // Stream writer...
         QTextStream out(&file);

         for(int i=0;i<source[0].size();i++)
         {
            for(int j=0;j<source.size();j++)
               out << source[j][i] << " ";
            out << endl;
         }
        file.close();
      }
      else
      {
         QMessageBox::critical(this,strtitle, "Cannot write to file");
      }
   }
}


/**
   \brief Handles undo operation
**/
void MainWindow::on_actionUndo_triggered()
{
   if(!undoable)
      return;

   // Swaps the current and undo buffers.
   REFERENCEPOINTS r = RefPoints;
   std::vector<SIGNALDATA> s=SignalData;
   SignalData=SignalDataUndo;
   RefPoints=RefPointsUndo;
   SignalDataUndo = s;
   RefPointsUndo = r;

   // Recompute the relations, update the active relations, etc.
   RefDialog->SetReferencePoints(RefPoints);             // Update GUI with reference points
   ComputeRelations();                                   // Update GUI with relations
}

/**
  \brief Show about program information
**/
void MainWindow::on_actionAbout_triggered()
{
   QMessageBox::about(this, "About",
   "<p><b>SynScopeV</b> - Offline visualization and alignment tool for multiple source signals and videos</p>\n"
   "<p>Version 1.0</p>"
   "<p>(c) 2009,2010 Daniel Roggen</p>"
   "<p>This software is licensed under the terms of the GPL v.2 license.</p>"
   );
}
/**
  \brief Show a short program usage howto
**/
void MainWindow::on_actionHow_to_triggered()
{
   HelpDialog *dlg = new HelpDialog(this);
   dlg->exec();
   delete dlg;
}

void MainWindow::on_actionMerge_linked_files_triggered()
{
    MergeFiles();
}




/**
  \brief Shows/hides the dialog with the relations
**/
void MainWindow::on_actionShow_reference_points_and_links_triggered()
{
   if(!RefDialog->isVisible())
      RefDialog->show();
   else
      RefDialog->hide();

}


void MainWindow::on_actionAdd_reference_point_triggered()
{
   on_AddReference();
}


void MainWindow::on_actionClear_reference_points_triggered()
{
   on_RemoveReference(-1);
}



/*
   We employ a counter for DeafToVideoSliderEvents because the video scrolling is asynchronous.
   Thus, upon change of offset, we can't just stop being deaf... as the offset change will only come later.
   We know how many videos should change, so we use the counter to detect when in principle it's again the user scrolling.
*/
void MainWindow::on_Video_tick ( qint64 time )
{
   QObject *s = sender();

   if(DeafToVideoSliderEvents)
   {
      DeafToVideoSliderEvents--;
      return;
   }

   for(int i=0;i<VideoViewData.size();i++)
   {
      if(VideoViewData[i].mo == s)
      {
         on_Source_Slided(VID2IDX(i),time);
         break;
      }
   }
}

void MainWindow::on_videoPlayPauseButton(bool)
{
   QObject *s = sender();

   for(int i=0;i<VideoViewData.size();i++)
   {
      if(VideoViewData[i].button == s)
      {
         //printf("on_videoPlayPauseButton: current state of vid: %d\n",VideoViewData[i].mo->state());
         // Change the state of the play
         if(VideoViewData[i].mo->state() == Phonon::PlayingState)
            VideoViewData[i].mo->pause();
         //if(VideoViewData[i].mo->state() == Phonon::PausedState)
         if(VideoViewData[i].mo->state() == Phonon::PausedState || VideoViewData[i].mo->state() == Phonon::StoppedState)
            VideoViewData[i].mo->play();
         return;
      }
   }
}

bool MainWindow::IsIdxVideo(int idx)
{
   if(idx<VideoViewData.size())
      return true;
   return false;
}
bool MainWindow::IsIdxSignal(int idx)
{
   if(idx>=VideoViewData.size())
      return true;
   return false;
}
int MainWindow::VID2IDX(int vid)
{
   return vid;
}
int MainWindow::SID2IDX(int sid)
{
   return sid+VideoViewData.size();
}
int MainWindow::IDX2SID(int idx)
{
   assert(idx>=VideoViewData.size() && idx<GetNumSources());
   return idx-VideoViewData.size();
}
int MainWindow::IDX2VID(int idx)
{
   assert(idx>=0 && idx<VideoViewData.size());
   return idx;
}




/**
  \brief Returns the total number of sources (video + signals)
**/
int MainWindow::GetNumSources()
{
   return VideoViewData.size()+SignalData.size();
}



void MainWindow::on_actionSet_working_directory_triggered()
{
   QString dir = QFileDialog::getExistingDirectory(this, tr("Open Directory"),"",QFileDialog::ShowDirsOnly|QFileDialog::DontResolveSymlinks);
   printf("dir: %s\n",dir.toStdString().c_str());
   path.setCurrent(dir);
}


/**
  \brief Handles the repaint requests from the scopes.
**/
void MainWindow::on_Repaint()
{
   QObject *s = sender();
   for(unsigned i=0;i<ViewData.size();i++)
   {
      if(ViewData[i].scope == s)
      {
         PlotView(i);
         return;
      }
   }
}


/**
  \brief Terminates the program
**/
void MainWindow::on_action_Quit_triggered()
{
   close();
}

/**
  \brief Accessor

  Returns a source ID (not a view!)
**/
int MainWindow::GetPrimarySource()
{
   return source_primary;
}
/**
  \brief Accessor: number of signal views
**/
int MainWindow::GetNumSignalViews()
{
   return ViewData.size();
}
/**
  \brief Accessor: number of video views
**/
int MainWindow::GetNumVideoViews()
{
   return VideoViewData.size();
}

/************************************************************************************************/
/************************************************************************************************/
/************************************************************************************************/
/* DEV/INTERNAL FUNCTIONS   DEV/INTERNAL FUNCTIONS   DEV/INTERNAL FUNCTIONS   DEV/INTERNAL FUNCT*/
/************************************************************************************************/
/************************************************************************************************/
/************************************************************************************************/

void MainWindow::stateChanged(Phonon::State newState, Phonon::State  oldState)
{
   //printf("oldstate -> newstate  %d->%d\n",oldState,newState);
}

