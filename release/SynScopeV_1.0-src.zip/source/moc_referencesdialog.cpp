/****************************************************************************
** Meta object code from reading C++ file 'referencesdialog.h'
**
** Created: Mon 27. Jul 15:52:53 2009
**      by: The Qt Meta Object Compiler version 61 (Qt 4.5.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "referencesdialog.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'referencesdialog.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 61
#error "This file was generated using the moc from 4.5.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_ReferencesDialog[] = {

 // content:
       2,       // revision
       0,       // classname
       0,    0, // classinfo
      17,   12, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors

 // signals: signature, parameters, type, tag, flags
      18,   17,   17,   17, 0x05,
      37,   33,   17,   17, 0x05,
      58,   33,   17,   17, 0x05,
      81,   17,   17,   17, 0x05,

 // slots: signature, parameters, type, tag, flags
     106,   17,   17,   17, 0x08,
     138,  130,   17,   17, 0x08,
     184,   17,   17,   17, 0x08,
     215,   17,   17,   17, 0x08,
     247,  243,   17,   17, 0x08,
     282,  271,   17,   17, 0x08,
     308,  271,   17,   17, 0x08,
     332,  271,   17,   17, 0x08,
     356,  271,   17,   17, 0x08,
     386,  271,   17,   17, 0x08,
     410,  271,   17,   17, 0x08,
     486,  434,   17,   17, 0x08,
     531,  525,   17,   17, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_ReferencesDialog[] = {
    "ReferencesDialog\0\0AddReference()\0idx\0"
    "RemoveReference(int)\0ReferenceSelected(int)\0"
    "ChangedActiveRelations()\0"
    "on_pushButton_clicked()\0checked\0"
    "on_checkBox_EnableSignalLinking_toggled(bool)\0"
    "on_pushButton_Remove_clicked()\0"
    "on_pushButton_Add_clicked()\0a,b\0"
    "on_itemPressed(int,int)\0row,column\0"
    "on_cellActivated(int,int)\0"
    "on_cellChanged(int,int)\0on_cellClicked(int,int)\0"
    "on_cellDoubleClicked(int,int)\0"
    "on_cellEntered(int,int)\0on_cellPressed(int,int)\0"
    "currentRow,currentColumn,previousRow,previousColumn\0"
    "on_currentCellChanged(int,int,int,int)\0"
    "state\0on_LinkUIStateChanged(int)\0"
};

const QMetaObject ReferencesDialog::staticMetaObject = {
    { &QDialog::staticMetaObject, qt_meta_stringdata_ReferencesDialog,
      qt_meta_data_ReferencesDialog, 0 }
};

const QMetaObject *ReferencesDialog::metaObject() const
{
    return &staticMetaObject;
}

void *ReferencesDialog::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_ReferencesDialog))
        return static_cast<void*>(const_cast< ReferencesDialog*>(this));
    return QDialog::qt_metacast(_clname);
}

int ReferencesDialog::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: AddReference(); break;
        case 1: RemoveReference((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 2: ReferenceSelected((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 3: ChangedActiveRelations(); break;
        case 4: on_pushButton_clicked(); break;
        case 5: on_checkBox_EnableSignalLinking_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 6: on_pushButton_Remove_clicked(); break;
        case 7: on_pushButton_Add_clicked(); break;
        case 8: on_itemPressed((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 9: on_cellActivated((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 10: on_cellChanged((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 11: on_cellClicked((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 12: on_cellDoubleClicked((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 13: on_cellEntered((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 14: on_cellPressed((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 15: on_currentCellChanged((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3])),(*reinterpret_cast< int(*)>(_a[4]))); break;
        case 16: on_LinkUIStateChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        default: ;
        }
        _id -= 17;
    }
    return _id;
}

// SIGNAL 0
void ReferencesDialog::AddReference()
{
    QMetaObject::activate(this, &staticMetaObject, 0, 0);
}

// SIGNAL 1
void ReferencesDialog::RemoveReference(int _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void ReferencesDialog::ReferenceSelected(int _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void ReferencesDialog::ChangedActiveRelations()
{
    QMetaObject::activate(this, &staticMetaObject, 3, 0);
}
QT_END_MOC_NAMESPACE
