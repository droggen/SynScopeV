/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created: Mon 27. Jul 15:52:49 2009
**      by: The Qt Meta Object Compiler version 61 (Qt 4.5.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "mainwindow.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 61
#error "This file was generated using the moc from 4.5.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_MainWindow[] = {

 // content:
       2,       // revision
       0,       // classname
       0,    0, // classinfo
      21,   12, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors

 // slots: signature, parameters, type, tag, flags
      12,   11,   11,   11, 0x08,
      46,   11,   11,   11, 0x08,
      84,   11,   11,   11, 0x08,
     125,   11,   11,   11, 0x08,
     155,   11,   11,   11, 0x08,
     181,   11,   11,   11, 0x08,
     216,   11,   11,   11, 0x08,
     250,   11,   11,   11, 0x08,
     284,   11,   11,   11, 0x08,
     316,   11,   11,   11, 0x08,
     344,   11,   11,   11, 0x08,
     384,   11,   11,   11, 0x08,
     415,   11,   11,   11, 0x08,
     439,   11,   11,   11, 0x08,
     452,   11,   11,   11, 0x08,
     471,  465,   11,   11, 0x08,
     514,  499,   11,   11, 0x08,
     565,  557,   11,   11, 0x08,
     590,   11,   11,   11, 0x08,
     612,  608,   11,   11, 0x08,
     636,   11,   11,   11, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_MainWindow[] = {
    "MainWindow\0\0on_pushButton_ShowVideo_clicked()\0"
    "on_pushButton_ShowRelations_clicked()\0"
    "on_pushButton_ComputeRelations_clicked()\0"
    "on_pushButton_Test2_clicked()\0"
    "on_pushButton_3_clicked()\0"
    "on_pushButton_LoadSource_clicked()\0"
    "on_pushButton_ClearView_clicked()\0"
    "on_pushButton_ApplyView_clicked()\0"
    "on_pushButton_Correct_clicked()\0"
    "on_pushButtonPlay_clicked()\0"
    "on_pushButton_GridAlignCenter_clicked()\0"
    "on_pushButton_Center_clicked()\0"
    "on_pushButton_clicked()\0actionQuit()\0"
    "actionOpen()\0value\0on_Slider_valueChanged(int)\0"
    "button,samplex\0"
    "on_Scope_mousePressed(Qt::MouseButton,int)\0"
    "samplex\0on_Scope_mouseMoved(int)\0"
    "on_AddReference()\0idx\0on_RemoveReference(int)\0"
    "on_ChangedActiveRelations()\0"
};

const QMetaObject MainWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MainWindow,
      qt_meta_data_MainWindow, 0 }
};

const QMetaObject *MainWindow::metaObject() const
{
    return &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow))
        return static_cast<void*>(const_cast< MainWindow*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: on_pushButton_ShowVideo_clicked(); break;
        case 1: on_pushButton_ShowRelations_clicked(); break;
        case 2: on_pushButton_ComputeRelations_clicked(); break;
        case 3: on_pushButton_Test2_clicked(); break;
        case 4: on_pushButton_3_clicked(); break;
        case 5: on_pushButton_LoadSource_clicked(); break;
        case 6: on_pushButton_ClearView_clicked(); break;
        case 7: on_pushButton_ApplyView_clicked(); break;
        case 8: on_pushButton_Correct_clicked(); break;
        case 9: on_pushButtonPlay_clicked(); break;
        case 10: on_pushButton_GridAlignCenter_clicked(); break;
        case 11: on_pushButton_Center_clicked(); break;
        case 12: on_pushButton_clicked(); break;
        case 13: actionQuit(); break;
        case 14: actionOpen(); break;
        case 15: on_Slider_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 16: on_Scope_mousePressed((*reinterpret_cast< Qt::MouseButton(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 17: on_Scope_mouseMoved((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 18: on_AddReference(); break;
        case 19: on_RemoveReference((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 20: on_ChangedActiveRelations(); break;
        default: ;
        }
        _id -= 21;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
