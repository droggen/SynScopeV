/********************************************************************************
** Form generated from reading ui file 'sourcedialog.ui'
**
** Created: Thu 3. Sep 13:03:54 2009
**      by: Qt User Interface Compiler version 4.5.2
**
** WARNING! All changes made in this file will be lost when recompiling ui file!
********************************************************************************/

#ifndef UI_SOURCEDIALOG_H
#define UI_SOURCEDIALOG_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QDialogButtonBox>
#include <QtGui/QHeaderView>
#include <QtGui/QTableWidget>
#include <QtGui/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_SourceDialog
{
public:
    QVBoxLayout *verticalLayout;
    QTableWidget *tableWidget;
    QDialogButtonBox *buttonBox;

    void setupUi(QDialog *SourceDialog)
    {
        if (SourceDialog->objectName().isEmpty())
            SourceDialog->setObjectName(QString::fromUtf8("SourceDialog"));
        SourceDialog->resize(436, 253);
        verticalLayout = new QVBoxLayout(SourceDialog);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        tableWidget = new QTableWidget(SourceDialog);
        if (tableWidget->columnCount() < 3)
            tableWidget->setColumnCount(3);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        QTableWidgetItem *__qtablewidgetitem2 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(2, __qtablewidgetitem2);
        tableWidget->setObjectName(QString::fromUtf8("tableWidget"));
        tableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);
        tableWidget->setAlternatingRowColors(true);
        tableWidget->setSelectionMode(QAbstractItemView::SingleSelection);
        tableWidget->setSelectionBehavior(QAbstractItemView::SelectRows);

        verticalLayout->addWidget(tableWidget);

        buttonBox = new QDialogButtonBox(SourceDialog);
        buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Close);

        verticalLayout->addWidget(buttonBox);


        retranslateUi(SourceDialog);
        QObject::connect(buttonBox, SIGNAL(accepted()), SourceDialog, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), SourceDialog, SLOT(reject()));

        QMetaObject::connectSlotsByName(SourceDialog);
    } // setupUi

    void retranslateUi(QDialog *SourceDialog)
    {
        SourceDialog->setWindowTitle(QApplication::translate("SourceDialog", "Available data sources", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem = tableWidget->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QApplication::translate("SourceDialog", "File name", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem1 = tableWidget->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QApplication::translate("SourceDialog", "Number of channels", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem2 = tableWidget->horizontalHeaderItem(2);
        ___qtablewidgetitem2->setText(QApplication::translate("SourceDialog", "Number of samples", 0, QApplication::UnicodeUTF8));
        Q_UNUSED(SourceDialog);
    } // retranslateUi

};

namespace Ui {
    class SourceDialog: public Ui_SourceDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SOURCEDIALOG_H
