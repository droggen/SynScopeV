/*
   SynScopeV

   Copyright (C) 2008,2009,2010,2011:
         Daniel Roggen, droggen@gmail.com

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/


#include "SSViewStickman.h"
#include "StickmanWidget.h"


SSViewStickman::SSViewStickman(QWidget *parent) : SSViewAbstract(parent)
{

   printf("SSViewStickman::SSViewStickman\n");

   stickman=0;
   slider=0;
   box=0;

   length=0;



   // Stickman
   stickman = new StickmanWidget();
   stickman->setMinimumWidth(160);
   stickman->setMinimumHeight(100);


   // Slider
   slider = new QSliderExt(Qt::Horizontal,0);
   slider->setFocusPolicy(Qt::WheelFocus);   // To accept focus, and thus receive keyboard events, when: click, tab, mouse wheel.
   slider->setRange(0,length);

   // Box
   box = new QVBoxLayout();
   box->addWidget(stickman);
   box->addWidget(slider);
   setLayout(box);



   int success;
   success=connect(slider,SIGNAL(valueChanged(int)),this,SLOT(on_Slider_valueChanged(int)));

   success=connect(stickman,SIGNAL(mousePressed(Qt::MouseButton,int)),this,SLOT(on_View_mousePressed(Qt::MouseButton,int)));
   success=connect(stickman,SIGNAL(mouseMoved(int)),this,SLOT(on_View_mouseMoved(int)));
}

SSViewStickman::~SSViewStickman()
{
   printf("SSViewStickman::~SSViewStickman\n");

   if(box) delete box;
   if(slider) delete slider;
   if(stickman) delete stickman;
}



void SSViewStickman::paintEvent(QPaintEvent *event)
{
   printf("Stickman %p paint event\n",this);
   //stickman->update();
   stickman->repaint();
   QFrame::paintEvent(event);
}

void SSViewStickman::lengthChanged()
{
   length=0;
   // Find the length of the first non null quaternion vector.
   if(config.data_torso[0])
      length = config.data_torso[0]->size();
   else if(config.data_lua[0])
      length = config.data_lua[0]->size();
   else if(config.data_lla[0])
      length = config.data_lla[0]->size();
   else if(config.data_rua[0])
      length = config.data_rua[0]->size();
   else if(config.data_rla[0])
      length = config.data_rla[0]->size();

   bool ok;
   // Check that all quaterion vectors have the same length between them (and for all joints)
   ok=true;
   if(config.data_torso[0])
   {
      for(unsigned i=0;i<4;i++)
      {
         if(config.data_torso[i]->size()!=length)
            ok=false;
      }
   }
   if(!ok)
      config.data_torso[0] = config.data_torso[1] = config.data_torso[2] = config.data_torso[3] = 0;
   // Check that all quaterion vectors have the same length between them (and for all joints)
   ok=true;
   if(config.data_lua[0])
   {
      for(unsigned i=0;i<4;i++)
      {
         if(config.data_lua[i]->size()!=length)
            ok=false;
      }
   }
   if(!ok)
      config.data_lua[0] = config.data_lua[1] = config.data_lua[2] = config.data_lua[3] = 0;
   // Check that all quaterion vectors have the same length between them (and for all joints)
   ok=true;
   if(config.data_lla[0])
   {
      for(unsigned i=0;i<4;i++)
      {
         if(config.data_lla[i]->size()!=length)
            ok=false;
      }
   }
   if(!ok)
      config.data_lla[0] = config.data_lla[1] = config.data_lla[2] = config.data_lla[3] = 0;
   // Check that all quaterion vectors have the same length between them (and for all joints)
   ok=true;
   if(config.data_rua[0])
   {
      for(unsigned i=0;i<4;i++)
      {
         if(config.data_rua[i]->size()!=length)
            ok=false;
      }
   }
   if(!ok)
      config.data_rua[0] = config.data_rua[1] = config.data_rua[2] = config.data_rua[3] = 0;
   // Check that all quaterion vectors have the same length between them (and for all joints)
   ok=true;
   if(config.data_rla[0])
   {
      for(unsigned i=0;i<4;i++)
      {
         if(config.data_rla[i]->size()!=length)
            ok=false;
      }
   }
   if(!ok)
      config.data_rla[0] = config.data_rla[1] = config.data_rla[2] = config.data_rla[3] = 0;


   printf("Length of data: %d\n",length);

   // Set the slider range
   if(length==0)
      slider->setRange(0,0);
   else
      slider->setRange(0,length-1);
}

void SSViewStickman::setConfig(SSViewStickmanConfig c)
{
   config = c;


   // Check that either all or none of the quaternion vector is a null pointer. Set all to zero in case.
   if(config.data_torso[0]==0 || config.data_torso[1]==0 || config.data_torso[2]==0 || config.data_torso[3]==0)
      config.data_torso[0] = config.data_torso[1] = config.data_torso[2] = config.data_torso[3] = 0;
   if(config.data_lua[0]==0 || config.data_lua[1]==0 || config.data_lua[2]==0 || config.data_lua[3]==0)
      config.data_lua[0] = config.data_lua[1] = config.data_lua[2] = config.data_lua[3] = 0;
   if(config.data_lla[0]==0 || config.data_lla[1]==0 || config.data_lla[2]==0 || config.data_lla[3]==0)
      config.data_lla[0] = config.data_lla[1] = config.data_lla[2] = config.data_lla[3] = 0;
   if(config.data_rua[0]==0 || config.data_rua[1]==0 || config.data_rua[2]==0 || config.data_rua[3]==0)
      config.data_rua[0] = config.data_rua[1] = config.data_rua[2] = config.data_rua[3] = 0;
   if(config.data_rla[0]==0 || config.data_rla[1]==0 || config.data_rla[2]==0 || config.data_rla[3]==0)
      config.data_rla[0] = config.data_rla[1] = config.data_rla[2] = config.data_rla[3] = 0;




   lengthChanged();

}



void SSViewStickman::setTime(int t)
{
   // When the time is set programmatically we must ensure that no slider signal is emitted

   NoSliderEvents=true;
   slider->setSliderPosition(t);
   NoSliderEvents=false;
   repaint();

}

int SSViewStickman::getTime()
{
   return slider->sliderPosition();
}










void SSViewStickman::on_Slider_valueChanged(int value)
{
   printf("Stickman %p. slider changed to %d\n",this,value);
   /*printf("Available data:\n");
   printf("\t%p %p %p %p\n",config.data_torso[0],config.data_torso[1],config.data_torso[2],config.data_torso[3]);
   printf("\t%p %p %p %p\n",config.data_lua[0],config.data_lua[1],config.data_lua[2],config.data_lua[3]);
   printf("\t%p %p %p %p\n",config.data_lla[0],config.data_lla[1],config.data_lla[2],config.data_lla[3]);
   printf("\t%p %p %p %p\n",config.data_rua[0],config.data_rua[1],config.data_rua[2],config.data_rua[3]);
   printf("\t%p %p %p %p\n",config.data_rla[0],config.data_rla[1],config.data_rla[2],config.data_rla[3]);
   printf("Sizes: \n");
   if(config.data_torso[0]) printf("\t%d\n",config.data_torso[0]->size()); else printf("-\n");
   if(config.data_lua[0]) printf("\t%d\n",config.data_lua[0]->size()); else printf("-\n");
   if(config.data_lla[0]) printf("\t%d\n",config.data_lla[0]->size()); else printf("-\n");
   if(config.data_rua[0]) printf("\t%d\n",config.data_rua[0]->size()); else printf("-\n");
   if(config.data_rla[0]) printf("\t%d\n",config.data_rla[0]->size()); else printf("-\n");*/

   // Quaternions for the joints.
   std::vector<float> q_torso={1,0,0,0};
   std::vector<float> q_lua={1,0,0,0};
   std::vector<float> q_lla={1,0,0,0};
   std::vector<float> q_rua={1,0,0,0};
   std::vector<float> q_rla={1,0,0,0};

   // Get the value from the data, if it is available.
   if(config.data_torso[0])
   {
      // Check if the seek value is within the range of available data.
      if(value<config.data_torso[0]->size())
      {
         // Get the data in the quaternion.
         for(unsigned i=0;i<4;i++)
            q_torso[i] = config.data_torso[i]->operator[](value)/1000.0;
      }
   }
   // Get the value from the data, if it is available.
   if(config.data_lua[0])
   {
      // Check if the seek value is within the range of available data.
      if(value<config.data_lua[0]->size())
      {
         // Get the data in the quaternion.
         for(unsigned i=0;i<4;i++)
            q_lua[i] = config.data_lua[i]->operator[](value)/1000.0;
      }
   }
   // Get the value from the data, if it is available.
   if(config.data_lla[0])
   {
      // Check if the seek value is within the range of available data.
      if(value<config.data_lla[0]->size())
      {
         // Get the data in the quaternion.
         for(unsigned i=0;i<4;i++)
            q_lla[i] = config.data_lla[i]->operator[](value)/1000.0;
      }
   }
   // Get the value from the data, if it is available.
   if(config.data_rua[0])
   {
      // Check if the seek value is within the range of available data.
      if(value<config.data_rua[0]->size())
      {
         // Get the data in the quaternion.
         for(unsigned i=0;i<4;i++)
            q_rua[i] = config.data_rua[i]->operator[](value)/1000.0;
      }
   }
   // Get the value from the data, if it is available.
   if(config.data_rla[0])
   {
      // Check if the seek value is within the range of available data.
      if(value<config.data_rla[0]->size())
      {
         // Get the data in the quaternion.
         for(unsigned i=0;i<4;i++)
            q_rla[i] = config.data_rla[i]->operator[](value)/1000.0;
      }
   }
/*
   printf("q:\n");
   printf("%f %f %f %f\n",q_torso[0],q_torso[1],q_torso[2],q_torso[3]);
   printf("%f %f %f %f\n",q_lua[0],q_lua[1],q_lua[2],q_lua[3]);
   printf("%f %f %f %f\n",q_lla[0],q_lla[1],q_lla[2],q_lla[3]);
   printf("%f %f %f %f\n",q_rua[0],q_rua[1],q_rua[2],q_rua[3]);
   printf("%f %f %f %f\n",q_rla[0],q_rla[1],q_rla[2],q_rla[3]);
*/


   stickman->convertXsense2Stickman(q_torso,q_lua,q_lla,q_rua,q_rla, q_torso,q_lua,q_lla,q_rua,q_rla);

/*
   printf("q:\n");
   printf("%f %f %f %f\n",q_torso[0],q_torso[1],q_torso[2],q_torso[3]);
   printf("%f %f %f %f\n",q_lua[0],q_lua[1],q_lua[2],q_lua[3]);
   printf("%f %f %f %f\n",q_lla[0],q_lla[1],q_lla[2],q_lla[3]);
   printf("%f %f %f %f\n",q_rua[0],q_rua[1],q_rua[2],q_rua[3]);
   printf("%f %f %f %f\n",q_rla[0],q_rla[1],q_rla[2],q_rla[3]);
*/

   stickman->setJointsQ(q_torso,q_lua,q_lla,q_rua,q_rla);



   repaint();

   if(!NoSliderEvents)
      emit timeChanged(value);
}
/******************************************************************************
   Signals & Slots
*******************************************************************************
******************************************************************************/
void SSViewStickman::on_View_mousePressed(Qt::MouseButton button, int samplex)
{
   emit mousePressed(button,getTime());
}
void SSViewStickman::on_View_mouseMoved(int samplex)
{
   emit mouseMoved(getTime());
}
