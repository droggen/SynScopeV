/*
   SynScopeV

   Copyright (C) 2008,2009,2010,2011:
         Daniel Roggen, droggen@gmail.com

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/


#include "SSViewSignal.h"


SSViewSignal::SSViewSignal(QWidget *parent) : SSViewAbstract(parent)
{
   scope=0;
   slider=0;
   box=0;

    // Scope
   scope = new DScopeQTExtWidget(0,0,200,100,0);
   scope->setMinimumHeight(50);

   // Slider
   slider = new QSliderExt(Qt::Horizontal,0);
   slider->setFocusPolicy(Qt::WheelFocus);   // To accept focus, and thus receive keyboard events, when: click, tab, mouse wheel.

   // Box
   box = new QVBoxLayout();
   box->addWidget(scope);
   box->addWidget(slider);
   setLayout(box);



   // Add a handler
   int success;
   success=connect(slider,SIGNAL(valueChanged(int)),this,SLOT(on_Slider_valueChanged(int)));

   success=connect(scope,SIGNAL(Repaint()),this,SLOT(on_Repaint()));
   success=connect(scope,SIGNAL(panLeft()),slider,SLOT(scrollLeft()));
   success=connect(scope,SIGNAL(panRight()),slider,SLOT(scrollRight()));
   success=connect(scope,SIGNAL(mousePressed(Qt::MouseButton,int)),this,SLOT(on_View_mousePressed(Qt::MouseButton,int)));
   success=connect(scope,SIGNAL(mouseMoved(int)),this,SLOT(on_View_mouseMoved(int)));

}

SSViewSignal::~SSViewSignal()
{
   printf("SSViewSignal::~SSViewSignal");
   if(box) delete box;
   if(slider) delete slider;
   if(scope) delete scope;
}


void SSViewSignal::on_Repaint()
{
   update();
}

void SSViewSignal::paintEvent(QPaintEvent *event)
{
   scope->Plot(config.data,config.colors);

   QFrame::paintEvent(event);
}

void SSViewSignal::setConfig(SSViewSignalConfig c)
{
   config = c;

   scope->SetTitle(config.title);
   scope->SetAlignment(true);
   scope->SetGridPosition(true);


   if(config.yauto)
      scope->SetVAuto();
   else
      scope->SetVRange(config.yscale[0],config.yscale[1]);
   scope->HZoom(config.xscale);

   lengthChanged();
}

void SSViewSignal::setTime(int t)
{
   // When the time is set programmatically we must ensure that no slider signal is emitted

   NoSliderEvents=true;
   slider->setSliderPosition(t);
   NoSliderEvents=false;

}

int SSViewSignal::getTime()
{
   return slider->sliderPosition();
}

// Call this to indicate that the data length has changed, for instance due to resampling.
// It adapts the slided length accordingly
void SSViewSignal::lengthChanged()
{
   slider->setRange(0,config.data[0]->size());
}


void SSViewSignal::on_Slider_valueChanged(int value)
{
   scope->SetSampleOffset(value);
   update();

   if(!NoSliderEvents)
      emit timeChanged(value);
}

void SSViewSignal::on_View_mousePressed(Qt::MouseButton button, int samplex)
{
   emit mousePressed(button,samplex);
}

void SSViewSignal::on_View_mouseMoved(int samplex)
{
   emit mouseMoved(samplex);
}


