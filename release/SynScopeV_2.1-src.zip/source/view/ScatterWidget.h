/*
   SynScopeV

   Copyright (C) 2008,2009,2010,2011:
         Daniel Roggen, droggen@gmail.com

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

#ifndef __SCATTERWIDGET_H
#define __SCATTERWIDGET_H

#include <QWidget>
#include <QColor>
#include <QPoint>
#include <QRect>
#include <QPicture>
#include <QPainter>

class ScatterWidget : public QWidget
{
    Q_OBJECT        // must include this if you use Qt signals/slots

public:
    ScatterWidget(QWidget *parent=0);
    virtual ~ScatterWidget();


    virtual void SetSampleOffset(int value);
    virtual void SetRangePoint(int value);
    virtual void Plot(const std::vector<std::vector<int> *> x,const std::vector<std::vector<int> *> y,const std::vector<unsigned> &color);
    virtual void SetAutoscale(bool as);
    virtual void SetScale(int xmin,int ymin,int xmax,int ymax);

protected:

   //int s2x(int s,int smin,int smax,int pmin,int pmax);
   int s2x(int s);
   //int s2y(int s,int smin,int smax,int pmin,int pmax);
   int s2y(int s);
   int FindSmallestAbove(int target,int &factor,int &power);
   int XsTickSpacing(int &factor,int &power);
   int YvTickSpacing(int &factor,int &power);
   void DrawHGrid(unsigned fcolor_axis,unsigned fcolor_minor,unsigned fcolor_major,unsigned fcolor_text);
   void DrawVGrid(unsigned fcolor_axis,unsigned fcolor_minor,unsigned fcolor_major,unsigned fcolor_text);

   virtual void paintEvent(QPaintEvent *event);

   virtual void resizeEvent(QResizeEvent *event);

   //virtual void wheelEvent (QWheelEvent * event);
   //virtual void keyPressEvent(QKeyEvent * event);
   virtual void mousePressEvent ( QMouseEvent * event );
   virtual void mouseMoveEvent ( QMouseEvent * event );


 private:
   QImage pixmap;
   QPainter painter;
   int sampleoffset;
   int rangepoint;
   bool autoscale;
   int sxmin,sxmax,symin,symax;           // User-set scale
   int esxmin,esxmax,esymin,esymax;           // Effective scale
   int minspace;


signals:
   void Repaint();
   void mousePressed(Qt::MouseButton button,int samplex);
   void mouseMoved(int samplex);

};



#endif // __SCATTERWIDGET_H
