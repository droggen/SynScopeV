#ifndef EXPORTVIDEODIALOG_H
#define EXPORTVIDEODIALOG_H

#include <QtGui/QDialog>

namespace Ui {
    class ExportVideoDialog;
}

class ExportVideoDialog : public QDialog {
    Q_OBJECT
public:
    ExportVideoDialog(QWidget *parent = 0);
    ~ExportVideoDialog();

    unsigned getWidth();
    unsigned getHeight();
    unsigned getBitrate();
    unsigned getGop();
    unsigned getSignalStep();
    bool getTitle();
    bool getDouble();

protected:
    void changeEvent(QEvent *e);

private:
    Ui::ExportVideoDialog *m_ui;
};

#endif // EXPORTVIDEODIALOG_H
