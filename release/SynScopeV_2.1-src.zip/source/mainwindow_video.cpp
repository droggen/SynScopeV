/*
   SynScopeV

   Copyright (C) 2008,2009:
         Daniel Roggen, droggen@gmail.com

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

#include <QKeyEvent>
#include <QMessageBox>
#include <QPainter>
#include <QFileDialog>
#include <QFile>
#include <QTextStream>
#include <QXmlStreamWriter>
#include <QDir>
#include <QThread>
#include <QSplitter>
#include <QProgressDialog>
#include <Phonon/VideoWidget>

#include <string>
#include <vector>
#include <fstream>
#include <sstream>
#include <iostream>
#include <iterator>
#include <assert.h>

#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "referencesdialog.h"
#include "resampledialog.h"
#include "matlabcodedialog.h"
#include "sourcedialog.h"
#include "savesyncfiledialog.h"
#include "videowidgetext.h"
#include "helpdialog.h"
#include "cio.h"
//#include "helper.h"
#include "QVideoEncoder.h"
#include "QVideoDecoder.h"
#include "exportvideodialog.h"
#include "exportmosaicvideodialog.h"
#include "precisetimer.h"
#include "videopreviewdialog.h"

/*************************************************************************************************
**************************************************************************************************
* MainWindow   MainWindow   MainWindow   MainWindow   MainWindow   MainWindow   MainWindow
**************************************************************************************************
*************************************************************************************************/

/*************************************************************************************************
* VIDEO EXPORT   VIDEO EXPORT   VIDEO EXPORT   VIDEO EXPORT   VIDEO EXPORT   VIDEO EXPORT
*************************************************************************************************/


/**
  Return the parameters for the video encoding: frame size, bitrate, etc
**/
bool MainWindow::GetVideoParameters(unsigned &videow,unsigned &videoh,unsigned &bitrate,unsigned &gop,unsigned &signalstep,bool &drawtitle,bool &dbl)
{
   ExportVideoDialog *dlg = new ExportVideoDialog(this);
   if(dlg->exec() == QDialog::Rejected)
      return false;
   videow = dlg->getWidth();
   videoh = dlg->getHeight();
   bitrate = dlg->getBitrate();
   gop = dlg->getGop();
   signalstep = dlg->getSignalStep();
   drawtitle = dlg->getTitle();
   dbl = dlg->getDouble();
   delete dlg;
   return true;
}

/**
  \brief Generates a video from the primary source
**/
void MainWindow::on_actionVideo_from_primary_source_triggered()
{
   QString title("Export primary source to video");
   if(GetPrimarySource()==-1)
   {
      QMessageBox::information(this,title,"Error: no primary source selected");
      return;
   }
   if(!IsIdxSignal(GetPrimarySource()))
   {
      QMessageBox::information(this,title,"Error: the primary source must be a signal");
      return;
   }

   // Set the video parameters
   unsigned videow,videoh,bitrate,gop,signalstep;
   bool drawtitle,dbl;
   if(!GetVideoParameters(videow,videoh,bitrate,gop,signalstep,drawtitle,dbl))
      return;

   if(videow%8 || videoh%8)
   {
      QMessageBox::information(this,title,"Error: the video width and height must be a multiple of 8 pixels.");
      return;
   }
   QString videoFileName = QFileDialog::getSaveFileName(this, title,"video","Movie files (*.avi *.asf *.mpg)");
   if(videoFileName.isNull())
   {
      return;
   }


   int rv=SaveSignalToVideo(GetPrimarySource(),videow,videoh,bitrate,gop,signalstep,drawtitle,dbl,videoFileName,"Generating video...");
   if(rv!=0)
   {
      if(rv==-1)
         QMessageBox::information(this,title,"Error: unable to initialize the video encoder.");

   }


}


/**
  Save all the views in a video.
**/
void MainWindow::on_actionVideo_of_all_signal_sources_triggered()
{
   QString title("Export all signal sources to video");

   // Set the video parameters
   unsigned videow,videoh,bitrate,gop,signalstep;
   bool drawtitle,dbl;
   if(!GetVideoParameters(videow,videoh,bitrate,gop,signalstep,drawtitle,dbl))
      return;

   if(videow%8 || videoh%8)
   {
      QMessageBox::information(this,title,"Error: the video width and height must be a multiple of 8 pixels.");
      return;
   }
   QString videoFileName = QFileDialog::getSaveFileName(this,"Select the base file name for video export (each view is suffixed with the view number)","video","Movie files (*.avi *.asf *.mpg)");
   printf("video name: %s\n",videoFileName.toStdString().c_str());
   if(videoFileName.isNull())
   {
      return;
   }

   printf("Number of views: %d\n",ScopeViewData.size());

   // Iterate all the views
   for(unsigned v=0;v<GetNumSignalViews();v++)
   {
      QString fn = QString("%1_%2.mpg").arg(videoFileName).arg(v);
      QString pt = QString("Generating video of view %1").arg(v);
      printf("view %d\n",v);
      printf("in %s\n",fn.toStdString().c_str());
      int rv=SaveSignalToVideo(v,videow,videoh,bitrate,gop,signalstep,drawtitle,dbl,fn,pt);
      if(rv!=0)
      {
         if(rv==-1)
            QMessageBox::information(this,title,"Error: unable to initialize the video encoder.");

      }
   }
}





/**
  \brief Generate a mosaic video, very configurable
**/
void MainWindow::on_actionMosaic_video_triggered()
{
   std::vector<MOSAICVIDEOPARAM> mvp,mvptmp;
   std::vector<MOSAICSIGNALPARAM> msp,msptmp;

   QString title("Export signal mosaic to video");
   if(GetPrimarySource()==-1)
   {
      QMessageBox::information(this,title,"Error: no primary source selected");
      return;
   }
   /*if(!IsIdxSignal(GetPrimarySource()))
   {
      QMessageBox::information(this,title,"Error: the primary source must be a signal");
      return;
   }*/

   ExportMosaicVideoDialog *dlg = new ExportMosaicVideoDialog(this);


   // Generate default parameters moderately cleverly

   // Generate the video parameters
   int vidwidth=0;
   for(unsigned v=0,y=0;v<GetNumVideoViews();v++)
   {
      int w,h;
      bool ok;
      ok = GetVideoSize(VideoViewData[v].file,w,h);
      MOSAICVIDEOPARAM p;
      p.name = QString("V%1").arg(v);
      if(ok)
      {
         p.w=w;
         p.h=h;
         vidwidth = p.w;
      }
      else
      {
         p.w=0;
         p.h=0;
      }
      p.px=0;
      p.py=y;
      y+=p.h+20;
      p.render=true;
      p.view=v;               // Video index (VID)
      p.scale=1.0;
      mvp.push_back(p);

   }

   // Generate the signal parameters
   for(unsigned v=0;v<GetNumSignalViews();v++)
   {
      MOSAICSIGNALPARAM p;
      p.name=QString("S%1").arg(v);
      p.px = vidwidth;
      p.py=v*100;
      p.w = 128;
      p.h = 80;
      p.view=v;               // Signal index (SID)
      p.render=true;
      p.dbl=false;
      msp.push_back(p);

   }


   dlg->SetParam(mvp,msp);
   if(dlg->exec() == QDialog::Rejected)
      return;

   // Get the params
   int bitrate,gop,signalstep;
   bool drawtitle,drawhaxis,drawvaxis,drawframe,transparentscope,globaldouble;
   bool centercurrentsample;
   dlg->GetParam(mvptmp,msptmp,bitrate,gop,signalstep,drawtitle,drawhaxis,drawvaxis,drawframe,transparentscope,centercurrentsample,globaldouble);
   delete dlg;


   /*
   printf("MSP:\n");
   for(unsigned  i=0;i<msptmp.size();i++)
   {
      printf("%d. %d %d, %d %d, dbl: %d, ID: %d\n",i,msptmp[i].px,msptmp[i].py,msptmp[i].w,msptmp[i].h,msptmp[i].dbl, msptmp[i].view);
   }
   printf("MVP:\n");
   for(unsigned i=0;i<mvptmp.size();i++)
   {
      printf("%d. %d %d, %d %d, scale: %lf, ID: %d\n",i,mvptmp[i].px,mvptmp[i].py,mvptmp[i].w,mvptmp[i].h,mvptmp[i].scale,mvptmp[i].view);
   }*/



   // Prune the views not flagged for rendering
   msp.clear();
   for(unsigned i=0;i<msptmp.size();i++)
   {
      if(!msptmp[i].render)
         continue;
      msp.push_back(msptmp[i]);
   }
   // Prune the videos not flagged for rendering
   mvp.clear();
   for(unsigned i=0;i<mvptmp.size();i++)
   {
      if(!mvptmp[i].render)
         continue;
      mvp.push_back(mvptmp[i]);
   }

   /*
   printf("MSP:\n");
   for(unsigned  i=0;i<msp.size();i++)
   {
      printf("%d. %d %d, %d %d, dbl: %d, ID: %d\n",i,msp[i].px,msp[i].py,msp[i].w,msp[i].h,msp[i].dbl, msp[i].view);
   }
   printf("MVP:\n");
   for(unsigned i=0;i<mvp.size();i++)
   {
      printf("%d. %d %d, %d %d, scale: %lf ID: %d\n",i,mvp[i].px,mvp[i].py,mvp[i].w,mvp[i].h,mvp[i].scale,mvp[i].view);
   }*/

   // Find the size of the overall frame
   int maxw=0,maxh=0;
   // MSP
   for(unsigned i=0;i<msp.size();i++)
   {
      //printf("%d %d - %d %d (%d)\n",msp[i].px,msp[i].py,msp[i].w,msp[i].h,(int)msp[i].dbl);
      maxw = max((int)maxw,(int)(msp[i].px + msp[i].w*(msp[i].dbl?2:1)));
      maxh = max((int)maxh,(int)(msp[i].py + msp[i].h*(msp[i].dbl?2:1)));
   }
   // MVP
   for(unsigned i=0;i<mvp.size();i++)
   {
      //printf("%d %d - %d %d (x %lf)\n",mvp[i].px,mvp[i].py,mvp[i].w,mvp[i].h,mvp[i].scale);
      maxw = max((int)maxw,(int)(mvp[i].px + mvp[i].w*mvp[i].scale));
      maxh = max((int)maxh,(int)(mvp[i].py + mvp[i].h*mvp[i].scale));
   }

   //
   printf("maxw: %d maxh: %d\n",maxw,maxh);
   // Round to a multiple of 8
   if(maxw%8)
      maxw=((maxw>>3)+1)<<3;
   if(maxh%8)
      maxh=((maxh>>3)+1)<<3;

   printf("maxw: %d maxh: %d\n",maxw,maxh);


   // Prepare the render frame
   QImage mosaic(maxw,maxh,QImage::Format_RGB32);
   QPainter painter(&mosaic);


   // Prepare the signal plot helpers
   vector<vector<int> *> vd;		// data for the traces in this scope
   vector<unsigned> vc;			// colors  of the traces
   std::vector<PlotViewHelper*> pvh;
   for(unsigned i=0;i<msp.size();i++)
   {
      printf("Prepare plot view helper %d\n",i);
      PreparePlotView(msp[i].view,vd,vc);       // Prepare signal -> convert to signal IDX

      pvh.push_back(new PlotViewHelper(
            msp[i].w,msp[i].h,
            centercurrentsample,
            vd,vc,
            ScopeViewData[msp[i].view].yauto,ScopeViewData[msp[i].view].yscale[0],ScopeViewData[msp[i].view].yscale[1],ScopeViewData[msp[i].view].xscale,
            drawtitle ? ScopeViewData[msp[i].view].title : "",
            drawhaxis,drawvaxis,drawframe)
            );
   }

   // Prepare the video decoders
   std::vector<QVideoDecoder> pvideoh;
   pvideoh.resize(3);
   for(unsigned i=0;i<mvp.size();i++)
   {
      bool ok = pvideoh[i].openFile( VideoViewData[mvp[i].view].file );
      printf("Opening file %d: %d\n",i,(int)ok);
   }



   // find the max sample that is displayed in the primary view
   unsigned maxs;
   if(!IsIdxSignal(GetPrimarySource()))
   {
      // Source is a video - find the video length
      maxs = GetVideoLength(VideoViewData[IDX2VID(GetPrimarySource())].file);
   }
   else
   {
      // Source is a signal - find the signal length
      PreparePlotView(GetPrimarySource(),vd,vc);
      maxs = vd[0]->size();
   }


   // Get the file name

   QString videoFileName = QFileDialog::getSaveFileName(this,"Video file name","video","MPEG movie (*.*)");
   printf("video name: %s\n",videoFileName.toStdString().c_str());
   if(videoFileName.isNull())
   {
      return;
   }

   QVideoEncoder encoder;
   encoder.createFile(videoFileName,maxw*(globaldouble?2:1),maxh*(globaldouble?2:1),bitrate,gop);
   if(!encoder.isOk())
   {
      QMessageBox::information(this,title,"Can't initialize video encoder");
      return;
   }
   printf("file created\n");

   VideoPreviewDialog *VideoPreview = new VideoPreviewDialog(this);
   VideoPreview->show();
   QEventLoop evt;      // we use an event loop to allow for paint events to show on-screen the generated video


   // Iterate the samples
   unsigned totalrenderbytes=0;
   for(unsigned s=0;s<maxs;s+=signalstep)
   {
      printf("Iteration %d of %d\n",s,maxs);
      double t0,t1,t2,t3,t4,t5,t6;

      t0 = PreciseTimer::QueryTimer();

      // Clear the mosaic
      mosaic.fill(0);

      t1 = PreciseTimer::QueryTimer();

      // Compute the offsets for all views
      std::map<int,int> offsetout;

      ComputeAllSourceOffsetFrom(RelationsActive,GetPrimarySource(),s,offsetout);
      /*printf("Map computed for offset %d\n",s);
      for(std::map<int,int>::iterator it=offsetout.begin();it!=offsetout.end();it++)
      {
         printf("%d -> %d\n",it->first,it->second);
      }*/

      //
      for(unsigned i=0;i<mvp.size();i++)
      {
         std::map<int,int>::iterator it;
         it = offsetout.find(VID2IDX(mvp[i].view));         // ComputeAllSourceOffsetFrom returns a map with absolute ID
         int offset;
         // We don't necessarily always find an offset. If a view is selected for video export, but is not linked, it won't appear in offsetout
         if(it==offsetout.end())
            offset = 0;
         else
            offset = it->second;


         // Seek and get frame
         bool ok;
         ok = pvideoh[i].seekMs(offset);
         //printf("Video %d seek to %d. ok: %d\n",i,offset,(int)ok);
         QImage img;
         ok = pvideoh[i].getFrame(img);
         if(ok)
         {
            // Rescale the frame and render it in the mosaic
            QImage imgs = img.scaled(img.width()*mvp[i].scale,img.height()*mvp[i].scale);
            painter.drawImage(mvp[i].px,mvp[i].py,imgs);
         }


      }

      t2 = PreciseTimer::QueryTimer();


      // Render all the views in the helper
      for(unsigned i=0;i<msp.size();i++)
      {
         //printf("Plotting scope %d, view %d\n",i,msp[i].view);
         // Find the offset of the view msp[i].view
         std::map<int,int>::iterator it;
         it = offsetout.find(SID2IDX(ScopeViewData[msp[i].view].source));         // ComputeAllSourceOffsetFrom returns a map with absolute ID
         int offset;
         // We don't necessarily always find an offset. If a view is selected for video export, but is not linked, it won't appear in offsetout
         if(it==offsetout.end())
         {
            offset = 0;
            //printf(" no offset\n");
         }
         else
         {
            offset = it->second;
            //printf(" offset: %d\n",offset);
         }
         //printf("I %d. V %d. Offset: %d\n",i,msp[i].view,offset);
         pvh[i]->PlotOffset(offset);
      }

      t3 = PreciseTimer::QueryTimer();

      // Compose a mosaic with all the views
      for(unsigned i=0;i<msp.size();i++)
      {
         // Rescale
         QImage img = pvh[i]->GetImage()->scaled(msp[i].w*(msp[i].dbl?2:1),msp[i].h*(msp[i].dbl?2:1));


         if(transparentscope)
            {

            // Copy with transparent black.
            // In principle no clipping needed for target, as we computed the size of the target according to the sources

            //for(int y=0;y<img.height() && msp[i].py+y<mosaic.height();y++)       // do clipping for target
            for(int y=0;y<img.height();y++)
            {
               unsigned char *psrc,*pdst;
               psrc = img.scanLine(y);
               pdst = mosaic.scanLine(msp[i].py+y) + 4*msp[i].px;
               //for(int x=0;x<img.width() && msp[i].px+x<mosaic.width();x++)      // do clipping for target
               for(int x=0;x<img.width();x++)
               {
                  unsigned pixel = *(unsigned*)psrc;
                  if(pixel!=0)
                     *(unsigned*)pdst = pixel;

                  psrc+=4;
                  pdst+=4;
               }

            }
         }
         else
            painter.drawImage(msp[i].px,msp[i].py,img);
      }

      t4 = PreciseTimer::QueryTimer();

      int ret;
      if(globaldouble)
      {
         ret = encoder.encodeImage(mosaic.scaled(mosaic.width()*2,mosaic.height()*2));
      }
      else
         ret = encoder.encodeImage(mosaic);
      totalrenderbytes+=ret;

      t5 = PreciseTimer::QueryTimer();


      // Indicate progress
      VideoPreview->setImage(mosaic);
      VideoPreview->setInfoText(QString("Rendered %1 out of %2 (%3\%). Frame: %4 bytes. Total (w/o containter): %5 bytes (%6 MB)").arg(s).arg(maxs).arg((double)s*100.0/(double)maxs).arg(ret).arg(totalrenderbytes).arg(totalrenderbytes/1024/1024));
      if(VideoPreview->wasCanceled())
         break;
      evt.processEvents();

      t6 = PreciseTimer::QueryTimer();

      printf("fill: %lf vdecrdr: %lf plot: %lf\n",t1-t0,t2-t1,t3-t2);
      printf("   plotcomp: %lf enc: %lf view: %lf\n",t4-t3,t5-t4,t6-t5);


   }

   delete VideoPreview;

   encoder.close();

   // Delete the plot helpers
   for(unsigned i=0;i<pvh.size();i++)
      delete pvh[i];
}




/**
  Return value:
  0: ok
  -1: video encoder error
  -2: encoding cancelled
**/
int MainWindow::SaveSignalToVideo(unsigned source,unsigned videow,unsigned videoh,unsigned bitrate,unsigned gop,unsigned signalstep,bool drawtitle,bool dbl,QString videoFileName,QString progressTitle)
{
   printf("SaveSignalToVideo\n");

   // Need to give data, scope definition, and some parameters to the renderer.
   vector<vector<int> *> vd;		// data for the traces in this scope
   vector<unsigned> vc;			// colors  of the traces
   PreparePlotView(source,vd,vc);

   PlotViewHelper pvh(videow,videoh,true,vd,vc,ScopeViewData[source].yauto,ScopeViewData[source].yscale[0],ScopeViewData[source].yscale[1],ScopeViewData[source].xscale,
                  drawtitle ? ScopeViewData[source].title : "",true,true,true);



   // find the max sample
   unsigned maxs = vd[0]->size();

   // Iterate from start to end, generate a file...

   unsigned factor;
   if(!dbl)
      factor=1;
   else
      factor=2;
   QVideoEncoder encoder;
   encoder.createFile(videoFileName,videow*factor,videoh*factor,bitrate,gop);
   if(!encoder.isOk())
      return -1;




   QProgressDialog pdlg(progressTitle, "Abort", 0, maxs, this);
   pdlg.setWindowModality(Qt::WindowModal);
   pdlg.setValue(0);
   for(unsigned s=0;s<maxs;s+=signalstep)
   {
      pvh.PlotOffset(s);
      // save the image
      if(dbl)
      {
         QImage pixmapf=pvh.GetImage()->scaled(videow*factor,videoh*factor);
         encoder.encodeImage(pixmapf);
      }
      else
         encoder.encodeImage(*pvh.GetImage());

      // Indicate progress
      pdlg.setValue(s);
      if(pdlg.wasCanceled())
         return -2;
   }
   return 0;

}



void MainWindow::findlinks()
{
   printf("test\n");


   bool prepend;


   prepend=true;
   // Find disconnected graphs
   vector<RELATIONS> graphs = FindGraphs(RelationsActive);
   // Find the resample logic - only to check if there are signal relations available.
   map<int,RESAMPLEREL> m = ResampleLogic(graphs,prepend);

   printf("m size: %d\n",m.size());

   for(map<int,RESAMPLEREL>::iterator it=m.begin();it!=m.end();it++)
   {
      printf("Processing source %d (%s)\n",it->first,SignalData[IDX2SID(it->first)].filename.toStdString().c_str());

      // We dump it.

      RESAMPLEREL r = it->second;
      printf("Relation: m: %lf o: %lf\n",r.m,r.o);
      printf(" \tlc: %d lm: %d pc: %d pm: %d\n",r.l_c,r.l_matlab,r.p_c,r.p_matlab);


   }
   /*
      if(!IsIdxSignal(it->first))
      {
         printf("Source %d is not a signal, skipping\n",it->first);
         continue;
      }

      // In principle magnitude is <= 1 - what happens if not?
      assert(it->second.m<=1.0);



      // This is already done by the resample logic
      double o;
      o=it->second.o;
      int p;
      if(postpend)
         p=it->second.p_c;
      else
         p=0;
      printf("Calling ResampleSignalData; factor %lf offset %d postpend %d\n",it->second.m,o,p);
      SIGNALDATA sigdat = ResampleSignalData(SignalData[IDX2SID(it->first)],it->second.m,o,p);

      // In-place resample
      printf("store\n");
      SignalData[IDX2SID(it->first)] = sigdat;

      // Update the reference points accordingly
      printf("upd ref points\n");
      for(REFERENCEPOINTS::iterator r=RefPoints.begin();r!=RefPoints.end();r++)
      {
         if((*r)[0] == it->first)
            (*r)[1] = (int)(((double)(*r)[1])/it->second.m+o);
         if((*r)[2] == it->first)
            (*r)[3] = (int)(((double)(*r)[3])/it->second.m+o);
      }
   }*/




}






void MainWindow::image2Pixmap(QImage &img,QPixmap &pixmap)
{
   // Convert the QImage to a QPixmap for display
   pixmap = QPixmap(img.size());
   QPainter painter;
   painter.begin(&pixmap);
   painter.drawImage(0,0,img);
   painter.end();
}



