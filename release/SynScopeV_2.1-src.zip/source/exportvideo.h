/*
   SynScopeV

   Copyright (C) 2008,2009,2010:
         Daniel Roggen, droggen@gmail.com

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/



#ifndef __EXPORTVIDEO_H
#define __EXPORTVIDEO_H

#include <QEventLoop>
#include <QThread>
#include <vector>
#include <Phonon/VideoWidget>
#include <Phonon/MediaSource>
#include <Phonon/MediaObject>
#include "DScopeQT.h"
#include "videowidgetext.h"
#include "precisetimer.h"

/*
  Plot view helper wraps the data required to render a view in a standalone bitmap, e.g. for video rendering
*/
class PlotViewHelper
{
   protected:
      vector<vector<int> *> vd;
      vector<unsigned> vc;
      QImage pixmap;
      DScopeQT *scope;
      int videow,videoh;

   public:
      PlotViewHelper(int w,int h,bool center,vector<vector<int> *> &_vd,vector<unsigned> &_vc,bool vauto,int vmin,int vmax,int hzoom,string title,bool drawhaxis,bool drawvaxis,bool drawframe);
      ~PlotViewHelper();
      void PlotOffset(int offset);
      QImage *GetImage();
};



bool GetVideoSize(QString filename,int &w,int &h);
int GetVideoLength(QString filename);


#endif // __EXPORTVIDEO_H





