/*
   SynScopeV

   Copyright (C) 2008,2009:
         Daniel Roggen, droggen@gmail.com

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

#ifndef DATA_H
#define DATA_H

#include <Phonon/MediaObject>
#include <Phonon/VideoWidget>
#include <Phonon/AudioOutput>
#include <Phonon/VideoPlayer>
#include <Phonon/SeekSlider>
#include <Phonon/VolumeSlider>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QFrame>
#include <QtGui/QMainWindow>
#include <QFrame>
#include <QSlider>
#include <QVBoxLayout>
#include <QPushButton>
#include <QPointer>
#include <vector>
#include <sstream>
#include <iostream>
#include "dscopeqtextwidget.h"
#include "videowidgetext.h"
#include "guihelper.h"
#include "view/SSViewSignal.h"
#include "view/SSViewVideo.h"
#include "view/SSViewStickman.h"
#include "view/SSViewScatter.h"
#include "view/SSViewLabel.h"

//-------------------------------------------------------------------------------------------------
// Data structures
//-------------------------------------------------------------------------------------------------
struct SIGNALDATA
{
   std::vector<std::vector<int> > data;     // data[channel][sample]
   int centersample;
   QString filename;

};

enum SRCTYPE {SRCTYPESIGNAL, SRCTYPEVIDEO};
enum VIEWTYPE {VIEWTYPESCOPE, VIEWTYPESTICKMAN, VIEWTYPEVIDEO, VIEWTYPESCATTER, VIEWTYPELABEL};
typedef struct
{
   SRCTYPE srctype;
   int srcid;                 // Relative ID within the given source type
   int srcuid;                // Unique ID across all source types
} SRCID;
typedef struct
{
   VIEWTYPE viewtype;
   int viewnum;
} VIEWID;

typedef struct
{
   SSViewSignal *view;

   unsigned source;           // signal source (i.e. file)
   string title;
   vector<unsigned> traces;
   vector<unsigned> colors;
   int xscale;
   vector<int> yscale;
   bool yauto;
} SCOPEVIEWDATA;

typedef std::vector<SCOPEVIEWDATA> SCOPEVIEWDATAS;

typedef std::vector<std::vector<string> > SOURCEFILES;


typedef struct
{
   SSViewVideo *view;

   QString file;
   int centersample;
} VIDEOVIEWDATA;

typedef std::vector<VIDEOVIEWDATA> VIDEOVIEWDATAS;

typedef struct
{
   SSViewStickman *view;

   unsigned source;           // signal source (i.e. file)
   string title;
   vector<int> trace_torso;
   vector<int> trace_lua;
   vector<int> trace_lla;
   vector<int> trace_rua;
   vector<int> trace_rla;
   int centersample;
} STICKMANVIEWDATA;
typedef std::vector<STICKMANVIEWDATA> STICKMANVIEWDATAS;

typedef struct
{
   SSViewScatter *view;


   unsigned source;           // signal source (i.e. file)
   string title;
   bool autoscale;
   int xmin,ymin,xmax,ymax;
   unsigned numpoints;

   std::vector<int> x,y;        // x,y traces in the source
   std::vector<unsigned> colors;
   int centersample;
} SCATTERVIEWDATA;
typedef std::vector<SCATTERVIEWDATA> SCATTERVIEWDATAS;


typedef struct
{
   SSViewLabel *view;

   unsigned source;           // signal source (i.e. file)
   string title;
   QStringList subtitle;
   vector<unsigned> traces;
   vector<unsigned> colors;
   int xscale;
   vector<int> yscale;
   bool yauto;
} LABELVIEWDATA;

typedef std::vector<LABELVIEWDATA> LABELVIEWDATAS;

// This should be changed to a nice structure. REFERENCEPOINTS[pointno][0...3
// 0: source 1
// 1: position in source 1
// 2: source 2
// 3: position in source 2
typedef std::vector<std::vector<int> > REFERENCEPOINTS;


/*
  Store a relation between x1 and x2.
  x2 = b*x1 + a;
*/
typedef struct {
   int x1,x2;     // Source and destination
   bool s1,s2;    // indicates whether x1,x2 are signals.
   int tx1,tx2;   // 0-based type-specific source number (for both video and signals)
   double a,b;

} RELATION;
typedef std::vector<RELATION> RELATIONS;

typedef struct { double m,o; int l_c,l_matlab,p_c,p_matlab;} RESAMPLEREL;


RELATIONS FindGraph(RELATIONS &Relations, int x1);
bool IsRelationConflicting(RELATIONS &Relations, int x1,int x2);
QString RelationToText(RELATION &r);
vector<RELATIONS> FindGraphs(RELATIONS Relations);
//void ResampleStuff(vector<RELATIONS> Graphs);
void DoubleToRatio(double v,int &n,int &d,int maxd=10000);
QString GraphToString(vector<int> g);
std::vector<std::vector<int> > parse(char *data,bool &ok);
void ComputeAllSourceOffsetFrom(RELATIONS &RelationsActive,int sourceidx,int value,std::map<int,int> &offsetout);




//-------------------------------------------------------------------------------------------------
// SplitInVector
//-------------------------------------------------------------------------------------------------
// Returns false in case of failure.
// Only one split character is allowed
template<class T> bool SplitInVector(string str,string split,vector<T> &r,ios_base&(&b)(ios_base&)=dec)
{

   r.clear();
   QString qstr(str.c_str());
   QStringList sl = qstr.split(QString(split.c_str()),QString::SkipEmptyParts);
   for(int i=0;i<sl.size();i++)
   {
      std::istringstream iss(sl[i].toStdString());
      T j;
      if( !((iss >> b >> j).fail()))
         r.push_back(j);
      else
         return false;
   }
   return true;
}
template<class T> bool SplitInVector(QString qstr,QString split,vector<T> &r,ios_base&(&b)(ios_base&)=dec)
{
   r.clear();
   QStringList sl = qstr.split(split,QString::SkipEmptyParts);
   for(int i=0;i<sl.size();i++)
   {
      std::istringstream iss(sl[i].toStdString());
      T j;
      if( !((iss >> b >> j).fail()))
         r.push_back(j);
      else
         return false;
   }
   return true;
}


#endif // DATA_H
