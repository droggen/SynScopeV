#include "exportvideodialog.h"
#include "ui_exportvideodialog.h"

ExportVideoDialog::ExportVideoDialog(QWidget *parent) :
    QDialog(parent),
    m_ui(new Ui::ExportVideoDialog)
{
    m_ui->setupUi(this);
}

ExportVideoDialog::~ExportVideoDialog()
{
    delete m_ui;
}

void ExportVideoDialog::changeEvent(QEvent *e)
{
    QDialog::changeEvent(e);
    switch (e->type()) {
    case QEvent::LanguageChange:
        m_ui->retranslateUi(this);
        break;
    default:
        break;
    }
}

unsigned ExportVideoDialog::getWidth()
{
   return m_ui->spinBox_Width->value();
}
unsigned ExportVideoDialog::getHeight()
{
   return m_ui->spinBox_Height->value();
}
unsigned ExportVideoDialog::getBitrate()
{
   return m_ui->spinBox_Bitrate->value();
}
unsigned ExportVideoDialog::getGop()
{
   return m_ui->spinBox_Gop->value();
}
unsigned ExportVideoDialog::getSignalStep()
{
   return m_ui->spinBox_SignalStep->value();
}

bool ExportVideoDialog::getTitle()
{
   return m_ui->checkBox_Title->isChecked();
}

bool ExportVideoDialog::getDouble()
{
   return m_ui->checkBox_Double->isChecked();
}


