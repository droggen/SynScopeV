/*
   SynScopeV

   Copyright (C) 2008,2009,2010:
         Daniel Roggen, droggen@gmail.com

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/


#include "exportvideo.h"
#include "QVideoDecoder.h"

/******************************************************************************
*******************************************************************************
* PlotViewHelper   PlotViewHelper   PlotViewHelper   PlotViewHelper   PlotViewH
*******************************************************************************
******************************************************************************/
PlotViewHelper::PlotViewHelper(int w,int h,bool center,vector<vector<int> *> &_vd,vector<unsigned> &_vc,bool vauto,int vmin,int vmax,int hzoom,string title,bool drawhaxis,bool drawvaxis,bool drawframe)
{

   vd = _vd;
   vc = _vc;
   videow=w;
   videoh=h;
   pixmap = QImage(videow,videoh,QImage::Format_RGB32);
   printf("videow/h: %d %d\n",videow,videoh);
   printf("w/h: %d %d\n",w,h);
   printf("pixmap: %d %d\n",pixmap.width(),pixmap.height());
   scope = new DScopeQT(&pixmap,0,0,pixmap.width(),pixmap.height(),false);
   if(vauto)
      scope->SetVAuto();
   else
      scope->SetVRange(vmin,vmax);
   scope->HZoom(hzoom);
   scope->SetTitle(title);
   scope->SetEnableHGrid(drawhaxis);
   scope->SetEnableVGrid(drawvaxis);
   scope->SetEnableFrame(drawframe);



   if(center)
   {
      // Set alignment and grid position to have the offset sample in the middle (like in the UI).
      // Thus the 'current' sample corresponding to the current video frame is in the center of the scope.
      scope->SetAlignment(true);
      scope->SetGridPosition(true);
   }
   else
   {
      // For videos when not showing the axes, it may be nicer to have the 'current' sample corresponding to the current video frame on the right.
      scope->SetAlignment(false);
      scope->SetGridPosition(true);
      scope->SetRightAlignLast(false);
   }

}
PlotViewHelper::~PlotViewHelper()
{
   delete scope;
}
void PlotViewHelper::PlotOffset(int offset)
{
   scope->SetSampleOffset(offset);
   scope->Plot(vd,vc);
}
QImage *PlotViewHelper::GetImage()
{
   return &pixmap;
}




bool GetVideoSize(QString filename,int &w,int &h)
{
   QVideoDecoder decoder;
   decoder.openFile(filename);
   decoder.seekNextFrame();
   QImage img;
   bool ok = decoder.getFrame(img);
   if(!ok)
      return false;
   w = img.width();
   h = img.height();
   return true;
}

/**
   Returns the length of a video in milliseconds
**/
int GetVideoLength(QString filename)
{
   QVideoDecoder decoder;
   decoder.openFile(filename);
   return decoder.getVideoLengthMs();
}


