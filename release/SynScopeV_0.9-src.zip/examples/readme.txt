================================================================================
EXAMPLES   EXAMPLES   EXAMPLES   EXAMPLES   EXAMPLES   EXAMPLES   EXAMPLES   
================================================================================
This directory contains example files to test the program functionalities.

To test the program: 
1.1. Load the configuration file (e.g. demo.xml) in the program
1.2. Activate link between the sources (menu Links/Edit reference points and links)
1.3. Navigate through the data
1.4. Modify (add, remove) reference points between sources


-------------------
Example 1: demo.xml 
-------------------
Manipulation of acceleration and rotation sensors. Recording of two sensor nodes. Footage from 3 cameras.



