/****************************************************************************
** Meta object code from reading C++ file 'DScopeQTWidget.h'
**
** Created: Mon 27. Jul 15:52:52 2009
**      by: The Qt Meta Object Compiler version 61 (Qt 4.5.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "DScopeQTWidget.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'DScopeQTWidget.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 61
#error "This file was generated using the moc from 4.5.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_DScopeQTWidget[] = {

 // content:
       2,       // revision
       0,       // classname
       0,    0, // classinfo
       2,   12, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors

 // signals: signature, parameters, type, tag, flags
      31,   16,   15,   15, 0x05,
      73,   65,   15,   15, 0x05,

       0        // eod
};

static const char qt_meta_stringdata_DScopeQTWidget[] = {
    "DScopeQTWidget\0\0button,samplex\0"
    "mousePressed(Qt::MouseButton,int)\0"
    "samplex\0mouseMoved(int)\0"
};

const QMetaObject DScopeQTWidget::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_DScopeQTWidget,
      qt_meta_data_DScopeQTWidget, 0 }
};

const QMetaObject *DScopeQTWidget::metaObject() const
{
    return &staticMetaObject;
}

void *DScopeQTWidget::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_DScopeQTWidget))
        return static_cast<void*>(const_cast< DScopeQTWidget*>(this));
    if (!strcmp(_clname, "DScopeQT"))
        return static_cast< DScopeQT*>(const_cast< DScopeQTWidget*>(this));
    return QWidget::qt_metacast(_clname);
}

int DScopeQTWidget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: mousePressed((*reinterpret_cast< Qt::MouseButton(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 1: mouseMoved((*reinterpret_cast< int(*)>(_a[1]))); break;
        default: ;
        }
        _id -= 2;
    }
    return _id;
}

// SIGNAL 0
void DScopeQTWidget::mousePressed(Qt::MouseButton _t1, int _t2)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void DScopeQTWidget::mouseMoved(int _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}
QT_END_MOC_NAMESPACE
