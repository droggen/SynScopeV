/********************************************************************************
** Form generated from reading ui file 'resampledialog.ui'
**
** Created: Mon 24. Aug 14:00:03 2009
**      by: Qt User Interface Compiler version 4.5.2
**
** WARNING! All changes made in this file will be lost when recompiling ui file!
********************************************************************************/

#ifndef UI_RESAMPLEDIALOG_H
#define UI_RESAMPLEDIALOG_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QDialogButtonBox>
#include <QtGui/QGroupBox>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QRadioButton>
#include <QtGui/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_ResampleDialog
{
public:
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout;
    QGroupBox *groupBox;
    QRadioButton *radioButton_M_UD;
    QRadioButton *radioButton_M_NN;
    QGroupBox *groupBox_2;
    QRadioButton *radioButton_S_R;
    QRadioButton *radioButton_S_RO;
    QRadioButton *radioButton_S_ROP;
    QDialogButtonBox *buttonBox;

    void setupUi(QDialog *ResampleDialog)
    {
        if (ResampleDialog->objectName().isEmpty())
            ResampleDialog->setObjectName(QString::fromUtf8("ResampleDialog"));
        ResampleDialog->resize(451, 143);
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(ResampleDialog->sizePolicy().hasHeightForWidth());
        ResampleDialog->setSizePolicy(sizePolicy);
        verticalLayout = new QVBoxLayout(ResampleDialog);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        groupBox = new QGroupBox(ResampleDialog);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        QSizePolicy sizePolicy1(QSizePolicy::Preferred, QSizePolicy::Expanding);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(groupBox->sizePolicy().hasHeightForWidth());
        groupBox->setSizePolicy(sizePolicy1);
        radioButton_M_UD = new QRadioButton(groupBox);
        radioButton_M_UD->setObjectName(QString::fromUtf8("radioButton_M_UD"));
        radioButton_M_UD->setGeometry(QRect(10, 60, 131, 19));
        radioButton_M_NN = new QRadioButton(groupBox);
        radioButton_M_NN->setObjectName(QString::fromUtf8("radioButton_M_NN"));
        radioButton_M_NN->setGeometry(QRect(10, 20, 121, 19));
        radioButton_M_NN->setChecked(true);

        horizontalLayout->addWidget(groupBox);

        groupBox_2 = new QGroupBox(ResampleDialog);
        groupBox_2->setObjectName(QString::fromUtf8("groupBox_2"));
        radioButton_S_R = new QRadioButton(groupBox_2);
        radioButton_S_R->setObjectName(QString::fromUtf8("radioButton_S_R"));
        radioButton_S_R->setGeometry(QRect(11, 60, 191, 20));
        radioButton_S_RO = new QRadioButton(groupBox_2);
        radioButton_S_RO->setObjectName(QString::fromUtf8("radioButton_S_RO"));
        radioButton_S_RO->setGeometry(QRect(10, 40, 191, 19));
        radioButton_S_ROP = new QRadioButton(groupBox_2);
        radioButton_S_ROP->setObjectName(QString::fromUtf8("radioButton_S_ROP"));
        radioButton_S_ROP->setGeometry(QRect(10, 20, 191, 19));
        radioButton_S_ROP->setChecked(true);

        horizontalLayout->addWidget(groupBox_2);


        verticalLayout->addLayout(horizontalLayout);

        buttonBox = new QDialogButtonBox(ResampleDialog);
        buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
        buttonBox->setCenterButtons(true);

        verticalLayout->addWidget(buttonBox);


        retranslateUi(ResampleDialog);
        QObject::connect(buttonBox, SIGNAL(accepted()), ResampleDialog, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), ResampleDialog, SLOT(reject()));

        QMetaObject::connectSlotsByName(ResampleDialog);
    } // setupUi

    void retranslateUi(QDialog *ResampleDialog)
    {
        ResampleDialog->setWindowTitle(QApplication::translate("ResampleDialog", "Resample options", 0, QApplication::UnicodeUTF8));
        groupBox->setTitle(QApplication::translate("ResampleDialog", "Resample method", 0, QApplication::UnicodeUTF8));
        radioButton_M_UD->setText(QApplication::translate("ResampleDialog", "Upsample/downsample", 0, QApplication::UnicodeUTF8));
        radioButton_M_NN->setText(QApplication::translate("ResampleDialog", "Nearest neighbor", 0, QApplication::UnicodeUTF8));
        groupBox_2->setTitle(QApplication::translate("ResampleDialog", "Resample strategy", 0, QApplication::UnicodeUTF8));
        radioButton_S_R->setText(QApplication::translate("ResampleDialog", "Resample only", 0, QApplication::UnicodeUTF8));
        radioButton_S_RO->setText(QApplication::translate("ResampleDialog", "Resample, offset adjust", 0, QApplication::UnicodeUTF8));
        radioButton_S_ROP->setText(QApplication::translate("ResampleDialog", "Resample, offset adjust, pad right", 0, QApplication::UnicodeUTF8));
        Q_UNUSED(ResampleDialog);
    } // retranslateUi

};

namespace Ui {
    class ResampleDialog: public Ui_ResampleDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_RESAMPLEDIALOG_H
