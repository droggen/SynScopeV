/********************************************************************************
** Form generated from reading ui file 'referencesdialog.ui'
**
** Created: Mon 24. Aug 14:00:03 2009
**      by: Qt User Interface Compiler version 4.5.2
**
** WARNING! All changes made in this file will be lost when recompiling ui file!
********************************************************************************/

#ifndef UI_REFERENCESDIALOG_H
#define UI_REFERENCESDIALOG_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QCheckBox>
#include <QtGui/QDialog>
#include <QtGui/QFrame>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QListWidget>
#include <QtGui/QPushButton>
#include <QtGui/QSpacerItem>
#include <QtGui/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_ReferencesDialog
{
public:
    QVBoxLayout *verticalLayout_4;
    QHBoxLayout *horizontalLayout;
    QVBoxLayout *verticalLayout;
    QLabel *label_2;
    QListWidget *listWidget;
    QHBoxLayout *horizontalLayout_2;
    QSpacerItem *horizontalSpacer;
    QPushButton *pushButton_Add;
    QSpacerItem *horizontalSpacer_3;
    QPushButton *pushButton_Remove;
    QSpacerItem *horizontalSpacer_6;
    QPushButton *pushButton_Clear;
    QSpacerItem *horizontalSpacer_2;
    QVBoxLayout *verticalLayout_3;
    QLabel *label;
    QListWidget *listWidget_Equations;
    QFrame *line;
    QVBoxLayout *verticalLayout_2;
    QHBoxLayout *v_2;
    QSpacerItem *horizontalSpacer_4;
    QCheckBox *checkBox_EnableSignalLinking;
    QSpacerItem *horizontalSpacer_5;
    QFrame *LinkUIFrame;

    void setupUi(QDialog *ReferencesDialog)
    {
        if (ReferencesDialog->objectName().isEmpty())
            ReferencesDialog->setObjectName(QString::fromUtf8("ReferencesDialog"));
        ReferencesDialog->resize(384, 419);
        ReferencesDialog->setSizeGripEnabled(true);
        verticalLayout_4 = new QVBoxLayout(ReferencesDialog);
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        label_2 = new QLabel(ReferencesDialog);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        QFont font;
        font.setBold(true);
        font.setWeight(75);
        label_2->setFont(font);

        verticalLayout->addWidget(label_2);

        listWidget = new QListWidget(ReferencesDialog);
        listWidget->setObjectName(QString::fromUtf8("listWidget"));

        verticalLayout->addWidget(listWidget);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer);

        pushButton_Add = new QPushButton(ReferencesDialog);
        pushButton_Add->setObjectName(QString::fromUtf8("pushButton_Add"));

        horizontalLayout_2->addWidget(pushButton_Add);

        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_3);

        pushButton_Remove = new QPushButton(ReferencesDialog);
        pushButton_Remove->setObjectName(QString::fromUtf8("pushButton_Remove"));

        horizontalLayout_2->addWidget(pushButton_Remove);

        horizontalSpacer_6 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_6);

        pushButton_Clear = new QPushButton(ReferencesDialog);
        pushButton_Clear->setObjectName(QString::fromUtf8("pushButton_Clear"));

        horizontalLayout_2->addWidget(pushButton_Clear);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_2);


        verticalLayout->addLayout(horizontalLayout_2);


        horizontalLayout->addLayout(verticalLayout);

        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        label = new QLabel(ReferencesDialog);
        label->setObjectName(QString::fromUtf8("label"));
        label->setFont(font);

        verticalLayout_3->addWidget(label);

        listWidget_Equations = new QListWidget(ReferencesDialog);
        listWidget_Equations->setObjectName(QString::fromUtf8("listWidget_Equations"));
        listWidget_Equations->setModelColumn(0);

        verticalLayout_3->addWidget(listWidget_Equations);


        horizontalLayout->addLayout(verticalLayout_3);


        verticalLayout_4->addLayout(horizontalLayout);

        line = new QFrame(ReferencesDialog);
        line->setObjectName(QString::fromUtf8("line"));
        line->setFrameShape(QFrame::HLine);
        line->setFrameShadow(QFrame::Sunken);

        verticalLayout_4->addWidget(line);

        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        v_2 = new QHBoxLayout();
        v_2->setObjectName(QString::fromUtf8("v_2"));
        horizontalSpacer_4 = new QSpacerItem(0, 0, QSizePolicy::Expanding, QSizePolicy::Minimum);

        v_2->addItem(horizontalSpacer_4);

        checkBox_EnableSignalLinking = new QCheckBox(ReferencesDialog);
        checkBox_EnableSignalLinking->setObjectName(QString::fromUtf8("checkBox_EnableSignalLinking"));

        v_2->addWidget(checkBox_EnableSignalLinking);

        horizontalSpacer_5 = new QSpacerItem(0, 0, QSizePolicy::Expanding, QSizePolicy::Minimum);

        v_2->addItem(horizontalSpacer_5);


        verticalLayout_2->addLayout(v_2);

        LinkUIFrame = new QFrame(ReferencesDialog);
        LinkUIFrame->setObjectName(QString::fromUtf8("LinkUIFrame"));
        QSizePolicy sizePolicy(QSizePolicy::MinimumExpanding, QSizePolicy::MinimumExpanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(LinkUIFrame->sizePolicy().hasHeightForWidth());
        LinkUIFrame->setSizePolicy(sizePolicy);
        LinkUIFrame->setFrameShape(QFrame::StyledPanel);
        LinkUIFrame->setFrameShadow(QFrame::Raised);

        verticalLayout_2->addWidget(LinkUIFrame);


        verticalLayout_4->addLayout(verticalLayout_2);


        retranslateUi(ReferencesDialog);

        QMetaObject::connectSlotsByName(ReferencesDialog);
    } // setupUi

    void retranslateUi(QDialog *ReferencesDialog)
    {
        ReferencesDialog->setWindowTitle(QApplication::translate("ReferencesDialog", "Edit relations between data sources", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("ReferencesDialog", "Map src1(pos1) -> src2(pos2):", 0, QApplication::UnicodeUTF8));
        pushButton_Add->setText(QApplication::translate("ReferencesDialog", "Add ref", 0, QApplication::UnicodeUTF8));
        pushButton_Remove->setText(QApplication::translate("ReferencesDialog", "Remove ref", 0, QApplication::UnicodeUTF8));
        pushButton_Clear->setText(QApplication::translate("ReferencesDialog", "Clear refs", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("ReferencesDialog", "Link equations:", 0, QApplication::UnicodeUTF8));
        checkBox_EnableSignalLinking->setText(QApplication::translate("ReferencesDialog", "Enable source linking", 0, QApplication::UnicodeUTF8));
        Q_UNUSED(ReferencesDialog);
    } // retranslateUi

};

namespace Ui {
    class ReferencesDialog: public Ui_ReferencesDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_REFERENCESDIALOG_H
