/********************************************************************************
** Form generated from reading ui file 'matlabcodedialog.ui'
**
** Created: Mon 24. Aug 14:00:03 2009
**      by: Qt User Interface Compiler version 4.5.2
**
** WARNING! All changes made in this file will be lost when recompiling ui file!
********************************************************************************/

#ifndef UI_MATLABCODEDIALOG_H
#define UI_MATLABCODEDIALOG_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QPushButton>
#include <QtGui/QSpacerItem>
#include <QtGui/QTextEdit>
#include <QtGui/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_MatlabCodeDialog
{
public:
    QVBoxLayout *verticalLayout;
    QTextEdit *textEdit_Code;
    QHBoxLayout *horizontalLayout;
    QSpacerItem *horizontalSpacer_3;
    QPushButton *pushButton_Save;
    QSpacerItem *horizontalSpacer;
    QPushButton *pushButton_Copy;
    QSpacerItem *horizontalSpacer_2;
    QPushButton *pushButton_Close;
    QSpacerItem *horizontalSpacer_4;

    void setupUi(QDialog *MatlabCodeDialog)
    {
        if (MatlabCodeDialog->objectName().isEmpty())
            MatlabCodeDialog->setObjectName(QString::fromUtf8("MatlabCodeDialog"));
        MatlabCodeDialog->resize(400, 300);
        verticalLayout = new QVBoxLayout(MatlabCodeDialog);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        textEdit_Code = new QTextEdit(MatlabCodeDialog);
        textEdit_Code->setObjectName(QString::fromUtf8("textEdit_Code"));

        verticalLayout->addWidget(textEdit_Code);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_3);

        pushButton_Save = new QPushButton(MatlabCodeDialog);
        pushButton_Save->setObjectName(QString::fromUtf8("pushButton_Save"));

        horizontalLayout->addWidget(pushButton_Save);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer);

        pushButton_Copy = new QPushButton(MatlabCodeDialog);
        pushButton_Copy->setObjectName(QString::fromUtf8("pushButton_Copy"));

        horizontalLayout->addWidget(pushButton_Copy);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_2);

        pushButton_Close = new QPushButton(MatlabCodeDialog);
        pushButton_Close->setObjectName(QString::fromUtf8("pushButton_Close"));

        horizontalLayout->addWidget(pushButton_Close);

        horizontalSpacer_4 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_4);


        verticalLayout->addLayout(horizontalLayout);


        retranslateUi(MatlabCodeDialog);

        QMetaObject::connectSlotsByName(MatlabCodeDialog);
    } // setupUi

    void retranslateUi(QDialog *MatlabCodeDialog)
    {
        MatlabCodeDialog->setWindowTitle(QApplication::translate("MatlabCodeDialog", "Dialog", 0, QApplication::UnicodeUTF8));
        pushButton_Save->setText(QApplication::translate("MatlabCodeDialog", "Save...", 0, QApplication::UnicodeUTF8));
        pushButton_Copy->setText(QApplication::translate("MatlabCodeDialog", "Copy to clipboard", 0, QApplication::UnicodeUTF8));
        pushButton_Close->setText(QApplication::translate("MatlabCodeDialog", "Close", 0, QApplication::UnicodeUTF8));
        Q_UNUSED(MatlabCodeDialog);
    } // retranslateUi

};

namespace Ui {
    class MatlabCodeDialog: public Ui_MatlabCodeDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MATLABCODEDIALOG_H
