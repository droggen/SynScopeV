/********************************************************************************
** Form generated from reading ui file 'savesyncfiledialog.ui'
**
** Created: Mon 24. Aug 14:00:03 2009
**      by: Qt User Interface Compiler version 4.5.2
**
** WARNING! All changes made in this file will be lost when recompiling ui file!
********************************************************************************/

#ifndef UI_SAVESYNCFILEDIALOG_H
#define UI_SAVESYNCFILEDIALOG_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QListWidget>
#include <QtGui/QPushButton>
#include <QtGui/QSpacerItem>
#include <QtGui/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_SaveSyncFileDialog
{
public:
    QVBoxLayout *verticalLayout_4;
    QHBoxLayout *horizontalLayout_3;
    QVBoxLayout *verticalLayout;
    QLabel *label;
    QListWidget *listWidget_Sources;
    QHBoxLayout *horizontalLayout_2;
    QVBoxLayout *verticalLayout_2;
    QLabel *label_2;
    QListWidget *listWidget_Order;
    QVBoxLayout *verticalLayout_3;
    QSpacerItem *verticalSpacer;
    QPushButton *pushButton_Up;
    QPushButton *pushButton_Down;
    QSpacerItem *verticalSpacer_2;
    QHBoxLayout *horizontalLayout;
    QSpacerItem *horizontalSpacer_3;
    QPushButton *pushButton;
    QSpacerItem *horizontalSpacer;
    QPushButton *pushButton_2;
    QSpacerItem *horizontalSpacer_2;
    QPushButton *pushButton_3;
    QSpacerItem *horizontalSpacer_4;

    void setupUi(QDialog *SaveSyncFileDialog)
    {
        if (SaveSyncFileDialog->objectName().isEmpty())
            SaveSyncFileDialog->setObjectName(QString::fromUtf8("SaveSyncFileDialog"));
        SaveSyncFileDialog->resize(443, 252);
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/new/prefix1/icon0.bmp"), QSize(), QIcon::Normal, QIcon::Off);
        SaveSyncFileDialog->setWindowIcon(icon);
        SaveSyncFileDialog->setModal(true);
        verticalLayout_4 = new QVBoxLayout(SaveSyncFileDialog);
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        label = new QLabel(SaveSyncFileDialog);
        label->setObjectName(QString::fromUtf8("label"));

        verticalLayout->addWidget(label);

        listWidget_Sources = new QListWidget(SaveSyncFileDialog);
        listWidget_Sources->setObjectName(QString::fromUtf8("listWidget_Sources"));

        verticalLayout->addWidget(listWidget_Sources);


        horizontalLayout_3->addLayout(verticalLayout);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        label_2 = new QLabel(SaveSyncFileDialog);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        verticalLayout_2->addWidget(label_2);

        listWidget_Order = new QListWidget(SaveSyncFileDialog);
        listWidget_Order->setObjectName(QString::fromUtf8("listWidget_Order"));

        verticalLayout_2->addWidget(listWidget_Order);


        horizontalLayout_2->addLayout(verticalLayout_2);

        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_3->addItem(verticalSpacer);

        pushButton_Up = new QPushButton(SaveSyncFileDialog);
        pushButton_Up->setObjectName(QString::fromUtf8("pushButton_Up"));

        verticalLayout_3->addWidget(pushButton_Up);

        pushButton_Down = new QPushButton(SaveSyncFileDialog);
        pushButton_Down->setObjectName(QString::fromUtf8("pushButton_Down"));

        verticalLayout_3->addWidget(pushButton_Down);

        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_3->addItem(verticalSpacer_2);


        horizontalLayout_2->addLayout(verticalLayout_3);


        horizontalLayout_3->addLayout(horizontalLayout_2);


        verticalLayout_4->addLayout(horizontalLayout_3);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_3);

        pushButton = new QPushButton(SaveSyncFileDialog);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));

        horizontalLayout->addWidget(pushButton);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer);

        pushButton_2 = new QPushButton(SaveSyncFileDialog);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));

        horizontalLayout->addWidget(pushButton_2);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_2);

        pushButton_3 = new QPushButton(SaveSyncFileDialog);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));

        horizontalLayout->addWidget(pushButton_3);

        horizontalSpacer_4 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_4);


        verticalLayout_4->addLayout(horizontalLayout);


        retranslateUi(SaveSyncFileDialog);

        QMetaObject::connectSlotsByName(SaveSyncFileDialog);
    } // setupUi

    void retranslateUi(QDialog *SaveSyncFileDialog)
    {
        SaveSyncFileDialog->setWindowTitle(QApplication::translate("SaveSyncFileDialog", "Merge linked sources", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("SaveSyncFileDialog", "Linked sources:", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("SaveSyncFileDialog", "Order in destination file:", 0, QApplication::UnicodeUTF8));
        pushButton_Up->setText(QApplication::translate("SaveSyncFileDialog", "Move front", 0, QApplication::UnicodeUTF8));
        pushButton_Down->setText(QApplication::translate("SaveSyncFileDialog", "Move back", 0, QApplication::UnicodeUTF8));
        pushButton->setText(QApplication::translate("SaveSyncFileDialog", "Save selected linked sources...", 0, QApplication::UnicodeUTF8));
        pushButton_2->setText(QApplication::translate("SaveSyncFileDialog", "Save all linked sources...", 0, QApplication::UnicodeUTF8));
        pushButton_3->setText(QApplication::translate("SaveSyncFileDialog", "Cancel", 0, QApplication::UnicodeUTF8));
        Q_UNUSED(SaveSyncFileDialog);
    } // retranslateUi

};

namespace Ui {
    class SaveSyncFileDialog: public Ui_SaveSyncFileDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SAVESYNCFILEDIALOG_H
