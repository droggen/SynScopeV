/*
   SynScopeV

   Copyright (C) 2008,2009:
         Daniel Roggen, droggen@gmail.com

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

#ifndef DATA_H
#define DATA_H

#include <Phonon/MediaObject>
#include <Phonon/VideoWidget>
#include <Phonon/AudioOutput>
#include <Phonon/VideoPlayer>
#include <Phonon/SeekSlider>
#include <Phonon/VolumeSlider>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QFrame>
#include <QtGui/QMainWindow>
#include <QFrame>
#include <QSlider>
#include <QVBoxLayout>
#include <QPushButton>
#include <QPointer>
#include <vector>
#include "dscopeqtextwidget.h"
#include "videowidgetext.h"

//-------------------------------------------------------------------------------------------------
// Data structures
//-------------------------------------------------------------------------------------------------
struct SIGNALDATA
{
   std::vector<std::vector<int> > data;     // data[channel][sample]
   int centersample;
   QString filename;

};

struct VIEWDATA
{
   QFrame *frame;
   //DScopeQTWidget *scope;
   DScopeQTExtWidget *scope;
   QSlider *slider;
   QVBoxLayout *box;

   unsigned source;           // signal source (i.e. file)
   string title;
   vector<unsigned> traces;
   vector<unsigned> colors;
   int xscale;
   vector<int> yscale;
   bool yauto;
};

typedef std::vector<VIEWDATA> VIEWDATAS;

typedef std::vector<std::vector<string> > SOURCEFILES;


typedef struct
{
   /*Phonon::MediaObject *mo;
   Phonon::MediaSource *src;
   VideoWidgetExt *vw;
   Phonon::AudioOutput *audioOutput;
   Phonon::SeekSlider *slider;
   QPushButton *button;
   Phonon::VolumeSlider *volumeSlider;
   QVBoxLayout *vbox;
   QHBoxLayout *hboxctrl,*hboxvid;
   QFrame *frame;*/
   QPointer<Phonon::MediaObject> mo;
   //QPointer<Phonon::MediaSource> src;
   Phonon::MediaSource *src;
   QPointer<VideoWidgetExt> vw;
   QPointer<Phonon::AudioOutput> audioOutput;
   QPointer<Phonon::SeekSlider> slider;
   QPointer<QPushButton> button;
   QPointer<Phonon::VolumeSlider> volumeSlider;
   QPointer<QVBoxLayout> vbox;
   QPointer<QHBoxLayout> hboxctrl,hboxvid;
   QPointer<QFrame> frame;
   QString file;
   int centersample;
} VIDEOVIEWDATA;

typedef std::vector<VIDEOVIEWDATA> VIDEOVIEWDATAS;



// This should be changed to a nice structure. REFERENCEPOINTS[pointno][0...3
// 0: source 1
// 1: position in source 1
// 2: source 2
// 3: position in source 2
typedef std::vector<std::vector<int> > REFERENCEPOINTS;


/*
  Store a relation between x1 and x2.
  x2 = b*x1 + a;
*/
typedef struct {
   int x1,x2;     // Source and destination
   bool s1,s2;    // indicates whether x1,x2 are signals.
   int tx1,tx2;   // 0-based type-specific source number (for both video and signals)
   double a,b;

} RELATION;
typedef std::vector<RELATION> RELATIONS;

typedef struct { double m,o; int l_c,l_matlab,p_c,p_matlab;} RESAMPLEREL;


RELATIONS FindGraph(RELATIONS &Relations, int x1);
bool IsRelationConflicting(RELATIONS &Relations, int x1,int x2);
QString RelationToText(RELATION &r);
vector<RELATIONS> FindGraphs(RELATIONS Relations);
//void ResampleStuff(vector<RELATIONS> Graphs);
void DoubleToRatio(double v,int &n,int &d,int maxd=10000);
QString GraphToString(vector<int> g);
std::vector<std::vector<int> > parse(char *data,bool &ok);

#endif // DATA_H
