/*
   SynScopeV

   Copyright (C) 2008,2009:
         Daniel Roggen, droggen@gmail.com

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

#include <fstream>
#include <sstream>
#include <iostream>


#include "data.h"


/**
  \brief Finds a graph connected to edge x1 following Relations

  Returns a set of relations that, when followed in order, allow to traverse the graph.

   This functions allows to make sure that there are no conflicting sets of relations active.
   A conflicting relation is for instance adding a relation between s1-s2 when the current active relations include s0-s1, s1-s2.
   In other words, this function looks for circular relations within the set.

    This function works even if the existing set of relations is conflicting; circular relations are correctly handled.

    A recursive implementation is avoided.
**/
RELATIONS FindGraph(RELATIONS &Relations, int x1)
{
   //printf("MainWindow::FindGraph: test for %d\n",x1);


   // Start from the source edge
   // cx1 format: cx1[path][timestep]
   vector<vector<int> > cx1(1,vector<int>(1,x1));     // Kepps the current x1 (last element) and the past x1 (from from to last-1 element)

   int c=0;

   RELATIONS RelationsFollowed;

   while(1)
   {
      /*for(int i=0;i<cx1.size();i++)
      {
         printf("cx1 path %d: ",i);
         for(int j=0;j<cx1[i].size();j++)
            printf("%d ",cx1[i][j]);
         printf("\n");
      }*/

      // Look in the relations if current x1 is used in the relation's x1. If not... no conflict. If yes, then follow relations
      vector<RELATION> r;
      r.clear();
      vector<int> ar;      // Alive relations
      ar.clear();

      // Iterate all current start points
      for(int i=0;i<cx1.size();i++)
      {
         // Iterate all relations, to see if one leads further away
         for(RELATIONS::iterator it = Relations.begin();it!=Relations.end();it++)
         {
            if(cx1[i].back() == it->x1)
            {
               // One might lead further away... Check if it was already followed to avoid circular recursion.
               vector<int>::iterator fit;
               fit = std::find(cx1[i].begin(),cx1[i].end()-1,it->x2);
               if(fit == cx1[i].end()-1)
               {
                  // Was not previously followed, hence follow it by keeping the relations to follow.
                  r.push_back(*it);
                  ar.push_back(i);
               }
            }
         }
      }

      /*printf("found relations to follow# %d.\n",r.size());
      if(r.size())
      {
         for(int i=0;i<r.size();i++)
            printf("found %d, for path number %d x1,x2: %d-%d\n",i,ar[i],r[i].x1,r[i].x2);
      }*/

      // No link to cx1 means it isn't conflicting
      if(!r.size())
         break;

      for(int i=0;i<r.size();i++)
         RelationsFollowed.push_back(r[i]);

      // Link may be indirectly conflicting -> follow link
      // Only the alive links are kept.
      // For those alive links, add the new end path
      vector<vector<int> > ncx1(ar.size());
      for(int i=0;i<ar.size();i++)
      {
         ncx1[i] = cx1[ar[i]];
         ncx1[i].push_back(r[i].x2);
      }

      cx1 = ncx1;
   }
   return RelationsFollowed;
}

/**
  \brief Checks whether the relation x1-x2 is in conflict with the existing relations Relations.

**/
bool IsRelationConflicting(RELATIONS &Relations, int x1,int x2)
{
   //printf("MainWindow::IsRelationConflicting: test for %d-%d\n",x1,x2);

   RELATIONS RelationsFollowed = FindGraph(Relations,x1);

   for(int i=0;i<RelationsFollowed.size();i++)
   {
      if(RelationsFollowed[i].x1 == x2 || RelationsFollowed[i].x2 == x2)
         return true;
   }
   return false;
}


// a1,a2: name of variable
QString RelationToText(RELATION &r)
{
   QString eq;
   eq.sprintf("%s%d = %s%d x %lf + %lf",r.s2?"S":"V",r.tx2,r.s1?"S":"V",r.tx1,r.b,r.a);
   return eq;
}


/**
   \brief Finds a set of disconnected graphs within Relations.

   Returns a vector<RELATIONS>......
   Each RELATIONS is a standalone graph.
**/
vector<RELATIONS> FindGraphs(RELATIONS Relations)
{
   /*printf("Relations:\n");
   for(int i=0;i<Relations.size();i++)
   {
      printf("%d\tx%d = x%d * %lf + %lf\n",i,Relations[i].x2,Relations[i].x1,Relations[i].b,Relations[i].a);
   }*/

   vector<RELATIONS> AllRelationsFollowed;
   RELATIONS RelationsFollowed;
   vector<int> edgeexplored;

   // Iterate through all the relation starting points.
   // For each, follow the relations until all edges are explored
   // Report and repeat
   for(int tg = 0; tg<Relations.size();tg++)
   {
      //printf("Starting to follow tg %d, %d\n",tg,Relations[tg].x1);


      // Check if the new target graph is already belonging to a relation graph
      vector<int>::iterator fit;
      fit = std::find(edgeexplored.begin(),edgeexplored.end(),Relations[tg].x1);
      if(fit != edgeexplored.end())
      {
         //printf("Already followed %d\n",Relations[tg].x1);
         continue;
      }


      RelationsFollowed = FindGraph(Relations, Relations[tg].x1);
      AllRelationsFollowed.push_back(RelationsFollowed);

      // Store the edge explored.
      for(int i=0;i<RelationsFollowed.size();i++)
      {
         edgeexplored.push_back(RelationsFollowed[i].x1);
         edgeexplored.push_back(RelationsFollowed[i].x2);
      }
      /*printf("For tg %d, edges explored: ",tg);
      for(int i=0;i<edgeexplored.size();i++)
         printf("%d ",edgeexplored[i]);
      printf("\n");*/


   }  // tg
   return AllRelationsFollowed;


}
/**
  \brief Converts double v to ratio of integers n/d, where d is at most maxd.
**/
void DoubleToRatio(double v,int &n,int &d,int maxd)
{
   n=1;
   d=1;
   while((v*d)-floor(v*d)!=0 && d<maxd)
      d*=10;
   n=floor(v*d);
}

/**
  \brief Converts vector<int> g to a string representation of the form "g[0]-g[1]-g[2]...-g[n]".
**/
QString GraphToString(vector<int> g)
{
   QString str;
   for(int j=0;j<g.size();j++)
   {
      str+=QString("S%1").arg(g[j]);
      if(j!=g.size()-1)
         str+="-";
   }
   return str;
}

/**
   \brief parses a null-terminated block of data for space/tab delimited values.

**/
std::vector<std::vector<int> > parse(char *data,bool &ok)
{
   // Find the first non
   int idx=0;
   bool gotdata;
   bool first=true;
   ok=false;
   gotdata=false;

   std::vector<std::vector<int> > alldata;
   vector<int> linedata;

   idx=-1;
   while(1)    // byte at data[len] is 0, guaranteed by the callee.
   {
      idx++;

      //printf("%d\n",alldata.size());
      // Skip any space
      if(data[idx]==32 || data[idx]=='\t')
         continue;

      //printf("idx: %d data[idx]: %d\n",idx,(int)data[idx]);

      // Non-space: either number, syntax problem, or newline
      if((data[idx]>='0' && data[idx]<='9') || data[idx]=='-'  || data[idx]=='.')
      {
         //printf("number start\n");
         // it is a number -> look for end of number
         int idx2=idx;
         while(data[idx2]!=0 && ((data[idx2]>='0' && data[idx2]<='9') || data[idx2]=='.' || data[idx2]=='-'))
            idx2++;
         //printf("idx2: %d\n",idx2);
         //if(idx2>=len)
         //   break;
         char t = data[idx2];    // Keep byte
         data[idx2]=0;           // Null terminate buffer to parse in place
         int v=atoi(data+idx);
         data[idx2]=t;           // Restore buffer to initial state
         linedata.push_back(v);
         gotdata=true;
         idx=idx2-1;

         //printf("v: %d \n",v);
         continue;
      }
      if(data[idx]==13 || data[idx]==10 || data[idx]==0)
      {
         //printf("got newline\n");

         // got a newline. If we got data, then we store it in the vector.
         if(gotdata==true)
         {
           // for(int i=0;i<linedata.size();i++)
             //  printf("%d: %d\n ",i,linedata[i]);

            if(first)
            {
               alldata.resize(linedata.size());
               first=false;
            }
            if(linedata.size()!=alldata.size())
            {
               //printf("Size mismatch: %d %d at line %d\n",alldata.size(),linedata.size(),alldata[0].size());
               return alldata;
            }
            for(int i=0;i<linedata.size();i++)
            {
               alldata[i].push_back(linedata[i]);
            }
            linedata.clear();
            gotdata=false;
            /*if((alldata[0].size()%10000)==0)
               printf("%d %d\n",alldata.size(),alldata[0].size());*/
         }
        // continue;
      }
      if(data[idx]==0)
         break;

      //printf("Invalid file\n");

      //return alldata;
   }
   ok=true;
   return alldata;
}




