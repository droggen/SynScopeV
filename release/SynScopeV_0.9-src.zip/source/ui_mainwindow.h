/********************************************************************************
** Form generated from reading ui file 'mainwindow.ui'
**
** Created: Mon 24. Aug 14:00:03 2009
**      by: Qt User Interface Compiler version 4.5.2
**
** WARNING! All changes made in this file will be lost when recompiling ui file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QMainWindow>
#include <QtGui/QMenu>
#include <QtGui/QMenuBar>
#include <QtGui/QPushButton>
#include <QtGui/QStatusBar>
#include <QtGui/QTextEdit>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *action_Resample;
    QAction *actionLoad_configuration;
    QAction *actionSave_configuration;
    QAction *actionExport_Matlab_resample_code;
    QAction *actionText;
    QAction *actionMatrix;
    QAction *actionLoad_reference_points;
    QAction *actionShow_available_sources;
    QAction *actionAbout_Q;
    QAction *actionSave_primary_source;
    QAction *actionUndo;
    QAction *actionHow_to;
    QAction *actionAbout;
    QAction *actionMerge_linked_files;
    QAction *actionSave_reference_points;
    QAction *actionShow_reference_points_and_links;
    QAction *actionAdd_reference_point;
    QAction *actionRemove_reference_point;
    QAction *actionClear_reference_points;
    QAction *actionSet_working_directory;
    QAction *action_Quit;
    QWidget *centralWidget;
    QVBoxLayout *verticalLayout_2;
    QHBoxLayout *horizontalLayout_2;
    QTextEdit *lineEdit_Source;
    QPushButton *pushButton_LoadSource;
    QHBoxLayout *horizontalLayout;
    QTextEdit *lineEdit_View;
    QPushButton *pushButton_ApplyView;
    QMenuBar *menuBar;
    QMenu *menu_File;
    QMenu *menu_Tools;
    QMenu *menuHelp;
    QMenu *menuSource;
    QMenu *menuReferences_Links;
    QMenu *menuExport_link_equations_2;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(610, 503);
        QSizePolicy sizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(MainWindow->sizePolicy().hasHeightForWidth());
        MainWindow->setSizePolicy(sizePolicy);
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/icon2.bmp"), QSize(), QIcon::Normal, QIcon::Off);
        MainWindow->setWindowIcon(icon);
        MainWindow->setAutoFillBackground(true);
        action_Resample = new QAction(MainWindow);
        action_Resample->setObjectName(QString::fromUtf8("action_Resample"));
        actionLoad_configuration = new QAction(MainWindow);
        actionLoad_configuration->setObjectName(QString::fromUtf8("actionLoad_configuration"));
        actionSave_configuration = new QAction(MainWindow);
        actionSave_configuration->setObjectName(QString::fromUtf8("actionSave_configuration"));
        actionExport_Matlab_resample_code = new QAction(MainWindow);
        actionExport_Matlab_resample_code->setObjectName(QString::fromUtf8("actionExport_Matlab_resample_code"));
        actionText = new QAction(MainWindow);
        actionText->setObjectName(QString::fromUtf8("actionText"));
        actionMatrix = new QAction(MainWindow);
        actionMatrix->setObjectName(QString::fromUtf8("actionMatrix"));
        actionLoad_reference_points = new QAction(MainWindow);
        actionLoad_reference_points->setObjectName(QString::fromUtf8("actionLoad_reference_points"));
        actionShow_available_sources = new QAction(MainWindow);
        actionShow_available_sources->setObjectName(QString::fromUtf8("actionShow_available_sources"));
        actionAbout_Q = new QAction(MainWindow);
        actionAbout_Q->setObjectName(QString::fromUtf8("actionAbout_Q"));
        actionSave_primary_source = new QAction(MainWindow);
        actionSave_primary_source->setObjectName(QString::fromUtf8("actionSave_primary_source"));
        actionUndo = new QAction(MainWindow);
        actionUndo->setObjectName(QString::fromUtf8("actionUndo"));
        actionHow_to = new QAction(MainWindow);
        actionHow_to->setObjectName(QString::fromUtf8("actionHow_to"));
        actionAbout = new QAction(MainWindow);
        actionAbout->setObjectName(QString::fromUtf8("actionAbout"));
        actionMerge_linked_files = new QAction(MainWindow);
        actionMerge_linked_files->setObjectName(QString::fromUtf8("actionMerge_linked_files"));
        actionSave_reference_points = new QAction(MainWindow);
        actionSave_reference_points->setObjectName(QString::fromUtf8("actionSave_reference_points"));
        actionShow_reference_points_and_links = new QAction(MainWindow);
        actionShow_reference_points_and_links->setObjectName(QString::fromUtf8("actionShow_reference_points_and_links"));
        actionAdd_reference_point = new QAction(MainWindow);
        actionAdd_reference_point->setObjectName(QString::fromUtf8("actionAdd_reference_point"));
        actionRemove_reference_point = new QAction(MainWindow);
        actionRemove_reference_point->setObjectName(QString::fromUtf8("actionRemove_reference_point"));
        actionClear_reference_points = new QAction(MainWindow);
        actionClear_reference_points->setObjectName(QString::fromUtf8("actionClear_reference_points"));
        actionSet_working_directory = new QAction(MainWindow);
        actionSet_working_directory->setObjectName(QString::fromUtf8("actionSet_working_directory"));
        action_Quit = new QAction(MainWindow);
        action_Quit->setObjectName(QString::fromUtf8("action_Quit"));
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        verticalLayout_2 = new QVBoxLayout(centralWidget);
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setMargin(11);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        lineEdit_Source = new QTextEdit(centralWidget);
        lineEdit_Source->setObjectName(QString::fromUtf8("lineEdit_Source"));
        QSizePolicy sizePolicy1(QSizePolicy::Expanding, QSizePolicy::Fixed);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(lineEdit_Source->sizePolicy().hasHeightForWidth());
        lineEdit_Source->setSizePolicy(sizePolicy1);
        lineEdit_Source->setMinimumSize(QSize(0, 40));
        lineEdit_Source->setAcceptRichText(false);

        horizontalLayout_2->addWidget(lineEdit_Source);

        pushButton_LoadSource = new QPushButton(centralWidget);
        pushButton_LoadSource->setObjectName(QString::fromUtf8("pushButton_LoadSource"));

        horizontalLayout_2->addWidget(pushButton_LoadSource);


        verticalLayout_2->addLayout(horizontalLayout_2);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(6);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        lineEdit_View = new QTextEdit(centralWidget);
        lineEdit_View->setObjectName(QString::fromUtf8("lineEdit_View"));
        sizePolicy1.setHeightForWidth(lineEdit_View->sizePolicy().hasHeightForWidth());
        lineEdit_View->setSizePolicy(sizePolicy1);
        lineEdit_View->setMinimumSize(QSize(0, 50));
        lineEdit_View->setAcceptRichText(false);

        horizontalLayout->addWidget(lineEdit_View);

        pushButton_ApplyView = new QPushButton(centralWidget);
        pushButton_ApplyView->setObjectName(QString::fromUtf8("pushButton_ApplyView"));

        horizontalLayout->addWidget(pushButton_ApplyView);


        verticalLayout_2->addLayout(horizontalLayout);

        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 610, 19));
        menu_File = new QMenu(menuBar);
        menu_File->setObjectName(QString::fromUtf8("menu_File"));
        menu_Tools = new QMenu(menuBar);
        menu_Tools->setObjectName(QString::fromUtf8("menu_Tools"));
        menuHelp = new QMenu(menuBar);
        menuHelp->setObjectName(QString::fromUtf8("menuHelp"));
        menuSource = new QMenu(menuBar);
        menuSource->setObjectName(QString::fromUtf8("menuSource"));
        menuReferences_Links = new QMenu(menuBar);
        menuReferences_Links->setObjectName(QString::fromUtf8("menuReferences_Links"));
        menuExport_link_equations_2 = new QMenu(menuReferences_Links);
        menuExport_link_equations_2->setObjectName(QString::fromUtf8("menuExport_link_equations_2"));
        MainWindow->setMenuBar(menuBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        MainWindow->setStatusBar(statusBar);

        menuBar->addAction(menu_File->menuAction());
        menuBar->addAction(menuSource->menuAction());
        menuBar->addAction(menuReferences_Links->menuAction());
        menuBar->addAction(menu_Tools->menuAction());
        menuBar->addAction(menuHelp->menuAction());
        menu_File->addAction(actionLoad_configuration);
        menu_File->addAction(actionSave_configuration);
        menu_File->addAction(actionSet_working_directory);
        menu_File->addAction(action_Quit);
        menu_Tools->addAction(action_Resample);
        menu_Tools->addAction(actionUndo);
        menu_Tools->addSeparator();
        menu_Tools->addAction(actionExport_Matlab_resample_code);
        menuHelp->addAction(actionAbout);
        menuHelp->addAction(actionHow_to);
        menuHelp->addAction(actionAbout_Q);
        menuSource->addAction(actionShow_available_sources);
        menuSource->addAction(actionSave_primary_source);
        menuSource->addAction(actionMerge_linked_files);
        menuReferences_Links->addAction(actionShow_reference_points_and_links);
        menuReferences_Links->addAction(actionAdd_reference_point);
        menuReferences_Links->addAction(actionClear_reference_points);
        menuReferences_Links->addSeparator();
        menuReferences_Links->addAction(actionLoad_reference_points);
        menuReferences_Links->addAction(actionSave_reference_points);
        menuReferences_Links->addSeparator();
        menuReferences_Links->addAction(menuExport_link_equations_2->menuAction());
        menuExport_link_equations_2->addAction(actionMatrix);
        menuExport_link_equations_2->addAction(actionText);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "SynScopeV", 0, QApplication::UnicodeUTF8));
        action_Resample->setText(QApplication::translate("MainWindow", "&Resample linked signals...", 0, QApplication::UnicodeUTF8));
        action_Resample->setShortcut(QApplication::translate("MainWindow", "Ctrl+R", 0, QApplication::UnicodeUTF8));
        actionLoad_configuration->setText(QApplication::translate("MainWindow", "&Load configuration...", 0, QApplication::UnicodeUTF8));
        actionLoad_configuration->setShortcut(QApplication::translate("MainWindow", "Ctrl+L", 0, QApplication::UnicodeUTF8));
        actionSave_configuration->setText(QApplication::translate("MainWindow", "&Save configuration...", 0, QApplication::UnicodeUTF8));
        actionSave_configuration->setShortcut(QApplication::translate("MainWindow", "Ctrl+S", 0, QApplication::UnicodeUTF8));
        actionExport_Matlab_resample_code->setText(QApplication::translate("MainWindow", "Export Matlab resample code...", 0, QApplication::UnicodeUTF8));
        actionText->setText(QApplication::translate("MainWindow", "As text...", 0, QApplication::UnicodeUTF8));
        actionMatrix->setText(QApplication::translate("MainWindow", "As matrix...", 0, QApplication::UnicodeUTF8));
        actionLoad_reference_points->setText(QApplication::translate("MainWindow", "Load reference points...", 0, QApplication::UnicodeUTF8));
        actionShow_available_sources->setText(QApplication::translate("MainWindow", "Show available sources...", 0, QApplication::UnicodeUTF8));
        actionShow_available_sources->setShortcut(QApplication::translate("MainWindow", "Ctrl+I", 0, QApplication::UnicodeUTF8));
        actionAbout_Q->setText(QApplication::translate("MainWindow", "About QT...", 0, QApplication::UnicodeUTF8));
        actionSave_primary_source->setText(QApplication::translate("MainWindow", "Save primary source...", 0, QApplication::UnicodeUTF8));
        actionUndo->setText(QApplication::translate("MainWindow", "Undo resample", 0, QApplication::UnicodeUTF8));
        actionUndo->setShortcut(QApplication::translate("MainWindow", "Ctrl+Z", 0, QApplication::UnicodeUTF8));
        actionHow_to->setText(QApplication::translate("MainWindow", "How to...", 0, QApplication::UnicodeUTF8));
        actionHow_to->setShortcut(QApplication::translate("MainWindow", "F1", 0, QApplication::UnicodeUTF8));
        actionAbout->setText(QApplication::translate("MainWindow", "About...", 0, QApplication::UnicodeUTF8));
        actionMerge_linked_files->setText(QApplication::translate("MainWindow", "Merge and save sources..", 0, QApplication::UnicodeUTF8));
        actionSave_reference_points->setText(QApplication::translate("MainWindow", "Save reference points...", 0, QApplication::UnicodeUTF8));
        actionShow_reference_points_and_links->setText(QApplication::translate("MainWindow", "Edit reference points and links...", 0, QApplication::UnicodeUTF8));
        actionShow_reference_points_and_links->setShortcut(QApplication::translate("MainWindow", "Ctrl+W", 0, QApplication::UnicodeUTF8));
        actionAdd_reference_point->setText(QApplication::translate("MainWindow", "Add reference point", 0, QApplication::UnicodeUTF8));
        actionAdd_reference_point->setShortcut(QApplication::translate("MainWindow", "Ctrl++", 0, QApplication::UnicodeUTF8));
        actionRemove_reference_point->setText(QApplication::translate("MainWindow", "Remove reference point", 0, QApplication::UnicodeUTF8));
        actionRemove_reference_point->setShortcut(QApplication::translate("MainWindow", "Ctrl+-", 0, QApplication::UnicodeUTF8));
        actionClear_reference_points->setText(QApplication::translate("MainWindow", "Clear reference points", 0, QApplication::UnicodeUTF8));
        actionClear_reference_points->setShortcut(QApplication::translate("MainWindow", "Ctrl+C", 0, QApplication::UnicodeUTF8));
        actionSet_working_directory->setText(QApplication::translate("MainWindow", "Set working directory...", 0, QApplication::UnicodeUTF8));
        action_Quit->setText(QApplication::translate("MainWindow", "&Quit", 0, QApplication::UnicodeUTF8));
        pushButton_LoadSource->setText(QApplication::translate("MainWindow", "Load sources", 0, QApplication::UnicodeUTF8));
        pushButton_ApplyView->setText(QApplication::translate("MainWindow", "Apply view", 0, QApplication::UnicodeUTF8));
        menu_File->setTitle(QApplication::translate("MainWindow", "&File", 0, QApplication::UnicodeUTF8));
        menu_Tools->setTitle(QApplication::translate("MainWindow", "Resample", 0, QApplication::UnicodeUTF8));
        menuHelp->setTitle(QApplication::translate("MainWindow", "Help", 0, QApplication::UnicodeUTF8));
        menuSource->setTitle(QApplication::translate("MainWindow", "Source", 0, QApplication::UnicodeUTF8));
        menuReferences_Links->setTitle(QApplication::translate("MainWindow", "Links", 0, QApplication::UnicodeUTF8));
        menuExport_link_equations_2->setTitle(QApplication::translate("MainWindow", "Export link equations", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
