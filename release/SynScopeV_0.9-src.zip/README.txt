   SynScopeV

   Copyright (C) 2009:
         Daniel Roggen, droggen@gmail.com


History
-------

V 0.90 - 24.08.2009: Initial beta




License
-------

This software is licensed under the terms of the GPL v.2 license.


Dependencies
------------

- QT and QT/Phonon are required.
- DirectShow (Windows), Quicktime (OSX), or Xine/gstreamer (Linux).

Phonon is available by default on OSX and Linux in the QT distribution. Windows distributions of QT need to be re-compiled enabling phonon and direct-show backend. This includes the following steps:
- updating to mingw with gcc version 4.4
- installing directx sdk
- patching include files in the mingw directory
- configuring and compiling QT with phonon and the directshow backend.
See http://labs.trolltech.com/blogs/2009/07/15/phonon-and-mingw-a-story-about-true-windows-love/ for more informations.


